# Department Feedback System - Deployment Guide

## 🚀 GitHub Repository Setup

### Step 1: Create GitHub Repository
1. Go to [GitHub.com](https://github.com) and sign in
2. Click the "+" icon in the top right corner
3. Select "New repository"
4. Fill in repository details:
   - **Repository name**: `department-feedback-system`
   - **Description**: `A comprehensive Django-based feedback management system for educational institutions`
   - **Visibility**: Public (or Private if preferred)
   - **Initialize**: Do NOT check "Add a README file" (we already have one)
5. Click "Create repository"

### Step 2: Upload Project to GitHub

#### Option A: Using Git Command Line
```bash
# Navigate to your project directory
cd C:\Users\Sayuti\Desktop\Datti

# Initialize Git repository
git init

# Add all files (respecting .gitignore)
git add .

# Create initial commit
git commit -m "Initial commit: Complete Department Feedback System v1.0"

# Add GitHub repository as remote origin
git remote add origin https://github.com/YOUR_USERNAME/department-feedback-system.git

# Push to GitHub
git push -u origin main
```

#### Option B: Using GitHub Desktop
1. Download and install [GitHub Desktop](https://desktop.github.com/)
2. Open GitHub Desktop
3. Click "Add an Existing Repository from your Hard Drive"
4. Select your project folder: `C:\Users\Sayuti\Desktop\Datti`
5. Click "Create repository"
6. Add a commit message: "Initial commit: Complete Department Feedback System v1.0"
7. Click "Commit to main"
8. Click "Publish repository"
9. Choose your repository name and settings
10. Click "Publish Repository"

#### Option C: Using GitHub Web Interface (for smaller projects)
1. In your new GitHub repository, click "uploading an existing file"
2. Drag and drop your project files (excluding venv, __pycache__, db.sqlite3)
3. Add commit message: "Initial commit: Complete Department Feedback System v1.0"
4. Click "Commit changes"

### Step 3: Verify Repository Setup
1. Check that all important files are uploaded:
   - ✅ README.md
   - ✅ requirements.txt
   - ✅ .gitignore
   - ✅ manage.py
   - ✅ feedback_system/ folder
   - ✅ feedback/ folder
   - ✅ templates/ folder
   - ✅ static/ folder
2. Verify .gitignore is working (no venv/, __pycache__, or db.sqlite3 files)
3. Check that README.md displays properly on GitHub

## 🖥️ Independent Project Execution

### Running on Your Current System

#### Quick Start Commands:
```bash
# Navigate to project directory
cd C:\Users\Sayuti\Desktop\Datti

# Activate virtual environment
venv\Scripts\activate

# Start Django server
python manage.py runserver

# Access in browser
# Go to: http://localhost:8000
```

#### Detailed Steps:
1. **Open Command Prompt or PowerShell**
2. **Navigate to project directory:**
   ```bash
   cd C:\Users\Sayuti\Desktop\Datti
   ```
3. **Activate virtual environment:**
   ```bash
   venv\Scripts\activate
   ```
   - You should see `(venv)` at the beginning of your command prompt
4. **Start the Django development server:**
   ```bash
   python manage.py runserver
   ```
5. **Access the web interface:**
   - Open your web browser
   - Go to: `http://localhost:8000`
   - Login with test credentials from README.md

#### Stopping the Server:
- Press `Ctrl + C` in the command prompt to stop the server
- Type `deactivate` to exit the virtual environment

### Transferring to a Different Computer/System

#### Step 1: Transfer Project Files
**Option A: From GitHub (Recommended)**
```bash
# On the new computer, clone from GitHub
git clone https://github.com/YOUR_USERNAME/department-feedback-system.git
cd department-feedback-system
```

**Option B: Direct File Transfer**
1. Copy the entire project folder to the new computer
2. Exclude these folders/files when copying:
   - `venv/` (virtual environment)
   - `__pycache__/` (Python cache)
   - `db.sqlite3` (database - will be recreated)
   - `*.pyc` files

#### Step 2: Setup on New System

**Prerequisites Installation:**
1. **Install Python 3.8 or higher**
   - Windows: Download from [python.org](https://www.python.org/downloads/)
   - Mac: `brew install python3` or download from python.org
   - Linux: `sudo apt-get install python3 python3-pip` (Ubuntu/Debian)

2. **Verify Python installation:**
   ```bash
   python --version
   # or
   python3 --version
   ```

**Project Setup:**
```bash
# Navigate to project directory
cd path/to/department-feedback-system

# Create virtual environment
python -m venv venv
# or on some systems:
python3 -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Setup database
python manage.py makemigrations
python manage.py migrate

# Load sample data (optional)
python create_sample_data.py
python create_sample_feedback.py

# Create superuser (optional)
python manage.py createsuperuser

# Start server
python manage.py runserver
```

#### Step 3: Access the System
1. Open web browser
2. Go to: `http://localhost:8000`
3. Login with credentials from README.md

### Configuration for Different Systems

#### Windows-Specific Commands:
```bash
# Activate virtual environment
venv\Scripts\activate

# Python command
python manage.py runserver
```

#### Mac/Linux-Specific Commands:
```bash
# Activate virtual environment
source venv/bin/activate

# Python command (might need python3)
python3 manage.py runserver
```

#### Port Configuration:
If port 8000 is busy, use a different port:
```bash
python manage.py runserver 8080
# Then access: http://localhost:8080
```

## 🔧 Troubleshooting

### Common Issues and Solutions:

#### 1. Python Not Found
**Error**: `'python' is not recognized as an internal or external command`
**Solution**: 
- Ensure Python is installed and added to PATH
- Try `python3` instead of `python`
- Reinstall Python with "Add to PATH" option checked

#### 2. Virtual Environment Issues
**Error**: Cannot activate virtual environment
**Solution**:
```bash
# Delete old venv and create new one
rmdir /s venv  # Windows
rm -rf venv    # Mac/Linux

python -m venv venv
```

#### 3. Database Issues
**Error**: Database errors or missing tables
**Solution**:
```bash
# Delete database and recreate
del db.sqlite3  # Windows
rm db.sqlite3   # Mac/Linux

python manage.py makemigrations
python manage.py migrate
python create_sample_data.py
```

#### 4. Permission Errors
**Error**: Permission denied
**Solution**:
- Run command prompt as Administrator (Windows)
- Use `sudo` for system-wide installations (Mac/Linux)
- Check folder permissions

#### 5. Port Already in Use
**Error**: Port 8000 is already in use
**Solution**:
```bash
# Use different port
python manage.py runserver 8080

# Or find and kill process using port 8000
netstat -ano | findstr :8000  # Windows
lsof -ti:8000 | xargs kill    # Mac/Linux
```

## 📋 Quick Reference

### Essential Commands:
```bash
# Start project
cd project-directory
venv\Scripts\activate          # Windows
source venv/bin/activate       # Mac/Linux
python manage.py runserver

# Stop project
Ctrl + C                       # Stop server
deactivate                     # Exit virtual environment
```

### Test Credentials:
- **Admin**: admin / admin123
- **Lecturer**: prof_smith / prof123
- **Student**: test_student / student123

### Important URLs:
- **Login**: http://localhost:8000/login/
- **Admin Dashboard**: http://localhost:8000/admin-dashboard/
- **Lecturer Dashboard**: http://localhost:8000/lecturer-dashboard/
- **Student Dashboard**: http://localhost:8000/student-dashboard/
