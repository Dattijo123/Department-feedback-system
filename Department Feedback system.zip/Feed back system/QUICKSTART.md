# 🚀 Quick Start Guide

## Step 1: Install Python
1. Download Python from https://www.python.org/downloads/
2. **IMPORTANT**: Check "Add Python to PATH" during installation
3. Restart your terminal/command prompt

## Step 2: Run Setup
**Windows:**
```cmd
setup.bat
```

**Linux/Mac:**
```bash
chmod +x setup.sh
./setup.sh
```

## Step 3: Create Sample Data (Optional)
```bash
# Activate virtual environment first
# Windows: venv\Scripts\activate
# Linux/Mac: source venv/bin/activate

python create_sample_data.py
```

## Step 4: Start the Server
```bash
python manage.py runserver
```

## Step 5: Access the Application
Open your browser and go to: http://localhost:8000

## Test Accounts (if you ran create_sample_data.py)
- **Admin**: username=`admin`, password=`admin123`
- **Students**: username=`student1-5`, password=`student123`
- **Lecturer**: username=`drsmith`, password=`lecturer123`

## What to Test
1. **Student Flow:**
   - Register as a new student
   - Verify email (check console for verification code)
   - Submit feedback on available surveys

2. **Admin Flow:**
   - Login as admin
   - View dashboard with analytics
   - Check survey details and responses

3. **Features to Explore:**
   - iOS-inspired responsive design
   - Anonymous feedback system
   - Real-time dashboard analytics
   - Survey management

## Troubleshooting
- **Python not found**: Make sure Python is in your PATH
- **Permission errors**: Run as administrator (Windows) or use sudo (Linux/Mac)
- **Database errors**: Delete `db.sqlite3` and run migrations again

## Next Steps
- Customize the surveys and questions
- Add your university's email domain validation
- Configure email settings for production
- Deploy to a web server

Enjoy your Department Feedback System! 🎉
