# Department Feedback System

A comprehensive Django-based feedback management system designed for educational institutions to collect, manage, and analyze student feedback across departments and courses.

## 🎯 Project Overview

The Department Feedback System is a complete 7-phase implementation that provides anonymous student feedback collection, comprehensive analytics, and robust administrative management. The system supports multiple user types with role-based access control and maintains student anonymity while providing valuable insights to administrators and lecturers.

## ✨ System Features

### Core Functionality
- **Anonymous Feedback Collection**: Students submit feedback without revealing their identity
- **Pseudonymous Tracking**: Prevents duplicate submissions while maintaining anonymity
- **Multi-Question Types**: Rating scales, yes/no, multiple choice, and text responses
- **Department-Based Organization**: Surveys organized by academic departments
- **Role-Based Access Control**: Different interfaces for admins, lecturers, and students

### Analytics & Reporting
- **Real-Time Analytics**: Live dashboard with system-wide statistics
- **Department Comparison**: Cross-department performance analysis
- **Trend Analysis**: 30-day comparison and historical tracking
- **Export Functionality**: CSV and report generation for survey data
- **Response Rate Tracking**: Participation monitoring and statistics

### Administrative Management
- **Department Management**: Full CRUD operations for departments
- **Course Management**: Complete course administration with department linking
- **User Management**: Create, edit, and delete user accounts
- **Survey Management**: Create surveys with multiple question types
- **System Configuration**: Comprehensive administrative controls

## 👥 User Types & Access Levels

### 🔴 Administrator
- **Full System Access**: Complete control over all system functions
- **User Management**: Create and manage all user types
- **Department & Course Management**: Add, edit, delete departments and courses
- **Survey Creation**: Create surveys for any department
- **Analytics Access**: System-wide analytics and reporting
- **Export Capabilities**: Generate reports and export data

### 🟡 Lecturer
- **Department-Restricted Access**: View only surveys from their assigned department
- **Course Feedback**: Access anonymous feedback for their courses
- **Analytics Viewing**: Department-specific analytics and trends
- **No Administrative Functions**: Cannot create users or manage system settings

### 🟢 Student
- **Survey Participation**: Submit anonymous feedback for their department
- **One-Time Submission**: Cannot retake completed surveys
- **Anonymous Access**: Identity protected through pseudonymous tracking
- **Department-Based Surveys**: See only surveys relevant to their department

## 🔐 Login Credentials

### Test Accounts (Development/Demo)

#### Administrator Accounts
```
Username: admin
Password: admin123
Role: Super Administrator
Access: Full system control
```

#### Lecturer Accounts
```
Username: prof_smith
Password: prof123
Department: CS (Cyber Security)
Access: CS department surveys and analytics

Username: prof_johnson  
Password: prof123
Department: IT (Information Technology)
Access: IT department surveys and analytics

Username: dr_brown
Password: prof123
Department: SE (Software Engineering)
Access: SE department surveys and analytics
```

#### Student Accounts
```
Username: test_student
Password: student123
Department: CS (Cyber Security)
Access: CS department surveys

Username: student1
Password: student123
Department: CS (Cyber Security)
Access: CS department surveys

Username: student2
Password: student123
Department: IT (Information Technology)
Access: IT department surveys

Username: student3
Password: student123
Department: SE (Software Engineering)
Access: SE department surveys
```

## 🚀 Installation & Setup

### Prerequisites
- Python 3.8 or higher
- Django 4.2+
- SQLite (default) or PostgreSQL/MySQL
- Modern web browser

### Quick Start
1. **Clone the Repository**
   ```bash
   git clone <repository-url>
   cd department-feedback-system
   ```

2. **Create Virtual Environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install Dependencies**
   ```bash
   pip install django
   ```

4. **Database Setup**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

5. **Create Superuser (Optional)**
   ```bash
   python manage.py createsuperuser
   ```

6. **Load Sample Data**
   ```bash
   python create_sample_data.py
   python create_sample_feedback.py
   ```

7. **Run Development Server**
   ```bash
   python manage.py runserver
   ```

8. **Access the System**
   - Open browser to `http://localhost:8000`
   - Login with provided test credentials

## 🏗️ System Architecture

### Technology Stack
- **Backend**: Django 4.2 (Python web framework)
- **Database**: SQLite (development) / PostgreSQL (production)
- **Frontend**: Bootstrap 5 + Custom CSS
- **Authentication**: Django's built-in authentication system
- **Security**: CSRF protection, pseudonymous tracking

### Key Components
- **Models**: Department, Course, Survey, Question, FeedbackSubmission, UserProfile
- **Views**: Role-based views with access control
- **Templates**: Responsive Bootstrap-based UI
- **Analytics**: Real-time data processing and visualization
- **Export**: CSV and report generation system

## 📈 Phase Implementation Summary

### Phase 1-4: Core System Foundation
- User authentication and role management
- Survey creation and question management
- Anonymous feedback submission system
- Basic user interface and navigation

### Phase 5: Core Analytics System
- Admin survey results viewing
- Lecturer dashboard with department restrictions
- Basic data visualization and statistics
- Anonymous feedback compilation

### Phase 6: Enhanced Analytics & Results
- System-wide analytics dashboard
- Export functionality (CSV and reports)
- Department comparison and trend analysis
- Enhanced data visualization

### Phase 7: System Polish & Administrative Management
- Complete department management (CRUD)
- Course management with department linking
- Enhanced user management capabilities
- Final system polish and optimization

## 🧪 Testing Instructions

### 1. Administrator Testing
```bash
# Login as admin
Username: admin
Password: admin123

# Test admin functions:
1. Go to Admin Dashboard: http://localhost:8000/admin-dashboard/
2. Create new department: http://localhost:8000/add-department/
3. Create new course: http://localhost:8000/add-course/
4. Create new user: http://localhost:8000/add-user/
5. Create new survey: http://localhost:8000/create-survey/
6. View analytics: http://localhost:8000/department-analytics/
7. Export survey data: Click export buttons on survey results
```

### 2. Lecturer Testing
```bash
# Login as lecturer
Username: prof_smith
Password: prof123

# Test lecturer functions:
1. View lecturer dashboard: http://localhost:8000/lecturer-dashboard/
2. View department surveys (CS only)
3. View survey results for surveys with feedback
4. Verify cannot access other departments' data
```

### 3. Student Testing
```bash
# Login as student
Username: test_student
Password: student123

# Test student functions:
1. View student dashboard: http://localhost:8000/student-dashboard/
2. Take available surveys for CS department
3. Verify cannot retake completed surveys
4. Verify anonymity is maintained
```

## 🔗 URL Reference

### Authentication URLs
- **Login**: `http://localhost:8000/login/`
- **Logout**: `http://localhost:8000/logout/`
- **Home**: `http://localhost:8000/`

### Admin URLs
- **Admin Dashboard**: `http://localhost:8000/admin-dashboard/`
- **Manage Users**: `http://localhost:8000/manage-users/`
- **Add User**: `http://localhost:8000/add-user/`
- **Manage Departments**: `http://localhost:8000/manage-departments/`
- **Add Department**: `http://localhost:8000/add-department/`
- **Manage Courses**: `http://localhost:8000/manage-courses/`
- **Add Course**: `http://localhost:8000/add-course/`
- **Create Survey**: `http://localhost:8000/create-survey/`
- **View All Surveys**: `http://localhost:8000/view-all-surveys/`
- **Department Analytics**: `http://localhost:8000/department-analytics/`

### Lecturer URLs
- **Lecturer Dashboard**: `http://localhost:8000/lecturer-dashboard/`
- **Survey Results**: `http://localhost:8000/lecturer/survey/{id}/results/`

### Student URLs
- **Student Dashboard**: `http://localhost:8000/student-dashboard/`
- **Take Survey**: `http://localhost:8000/survey/{id}/take/`

### Export URLs
- **CSV Export**: `http://localhost:8000/export/survey/{id}/csv/`
- **Report Export**: `http://localhost:8000/export/survey/{id}/pdf/`

## 🗄️ Database Models

### Core Models
- **Department**: Organizational units (CS, IT, SE)
- **Course**: Academic courses linked to departments
- **UserProfile**: Extended user information with roles and departments
- **Survey**: Feedback collection forms
- **Question**: Individual survey questions with multiple types
- **QuestionChoice**: Options for multiple choice questions

### Feedback Models
- **FeedbackSubmission**: Anonymous submission tracking
- **FeedbackResponse**: Individual question responses
- **CourseAssignment**: Links courses to lecturers and students

## 🔒 Security Features

### Authentication & Authorization
- Django's built-in authentication system
- Role-based access control (Admin, Lecturer, Student)
- Department-restricted access for lecturers
- Session management and CSRF protection

### Anonymity & Privacy
- Pseudonymous tracking using SHA-256 hashing
- No direct links between student identity and responses
- IP address logging for spam prevention only
- Anonymous feedback compilation and display

### Data Protection
- Input validation and sanitization
- SQL injection prevention through Django ORM
- XSS protection through template escaping
- Secure password handling with Django's authentication

## 📊 System Requirements

### Minimum Requirements
- **Python**: 3.8 or higher
- **Django**: 4.2 or higher
- **Memory**: 512MB RAM
- **Storage**: 100MB disk space
- **Browser**: Modern browser with JavaScript enabled

### Recommended Requirements
- **Python**: 3.10 or higher
- **Django**: 4.2 LTS
- **Memory**: 1GB RAM
- **Storage**: 500MB disk space
- **Database**: PostgreSQL for production

## 🚀 Production Deployment

### Environment Variables
```bash
DEBUG=False
SECRET_KEY=your-secret-key
DATABASE_URL=postgresql://user:pass@localhost/dbname
ALLOWED_HOSTS=yourdomain.com
```

### Database Migration
```bash
python manage.py collectstatic
python manage.py migrate
python manage.py createsuperuser
```

### Web Server Configuration
- Use Gunicorn or uWSGI for WSGI server
- Configure Nginx or Apache for static files
- Set up SSL/TLS certificates
- Configure database backups

## 📞 Support & Contact

For technical support or questions about the Department Feedback System:

- **Documentation**: This README file
- **Issues**: Create GitHub issues for bugs or feature requests
- **Testing**: Use provided test credentials for evaluation

## 📄 License

This project is developed for educational purposes. Please ensure compliance with your institution's policies and applicable privacy regulations when deploying in production.

---

**Department Feedback System v1.0** - Complete 7-Phase Implementation
*Developed with Django 4.2 and Bootstrap 5*
