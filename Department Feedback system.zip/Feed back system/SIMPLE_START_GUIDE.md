# 🚀 SIMPLE START GUIDE - Department Feedback System

## ⚡ QUICK START (3 Steps)

### Step 1: Open Command Prompt
- Press `Windows Key + R`
- Type `cmd` and press Enter
- OR search "Command Prompt" in Start menu

### Step 2: Go to Your Project Folder
```
cd C:\Users\Sayuti\Desktop\Datti
```

### Step 3: Run Setup
```
setup.bat
```

**That's it!** The system will start automatically.

---

## 🌐 ACCESS THE WEBSITE

1. **Open your web browser**
2. **Go to:** `http://localhost:8000`
3. **Login with:**
   - Admin: `admin` / `admin123`
   - Lecturer: `prof_smith` / `prof123`
   - Student: `test_student` / `student123`

---

## 🛑 HOW TO STOP

- Press `Ctrl + C` in the command prompt
- Type `deactivate` and press Enter

---

## 🔧 IF SETUP.BAT DOESN'T WORK

### Manual Method:
```
cd C:\Users\Sayuti\Desktop\Datti
venv\Scripts\activate
python manage.py runserver
```

Then go to: `http://localhost:8000`

---

## 📁 IMPORTANT FILES LOCATIONS

All files are in: `C:\Users\Sayuti\Desktop\Datti\`

**Key Files:**
- `setup.bat` - Automated setup script
- `README.md` - Complete documentation
- `DEPLOYMENT_GUIDE.md` - GitHub upload guide
- `manage.py` - Django management script
- `requirements.txt` - Required packages list

**Key Folders:**
- `venv\` - Virtual environment (Python packages)
- `feedback\` - Main application code
- `templates\` - Website pages
- `static\` - CSS and styling files

---

## 🆘 TROUBLESHOOTING

### Problem: "Python not found"
**Solution:** Install Python from https://www.python.org/downloads/
- Make sure to check "Add Python to PATH" during installation

### Problem: "setup.bat not working"
**Solution:** Use manual method above

### Problem: "Port 8000 already in use"
**Solution:** 
```
python manage.py runserver 8080
```
Then go to: `http://localhost:8080`

### Problem: Database errors
**Solution:**
```
python manage.py makemigrations
python manage.py migrate
python create_sample_data.py
```

---

## ✅ WHAT YOU SHOULD SEE

1. **Command Prompt:** Server running message
2. **Browser:** Login page at `http://localhost:8000`
3. **After Login:** Dashboard based on user type

---

## 🎯 NEXT STEPS

1. **Test Admin Features:**
   - Create departments
   - Create users
   - Create surveys
   - View analytics

2. **Test Lecturer Features:**
   - View survey results
   - Department analytics

3. **Test Student Features:**
   - Take surveys
   - Submit feedback

---

**🎉 Your Department Feedback System is ready to use!**
