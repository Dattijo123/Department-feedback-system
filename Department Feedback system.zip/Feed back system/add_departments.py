#!/usr/bin/env python
"""
Add all university departments to the system
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("Adding University Departments")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from feedback.models import Department
        
        # Department data
        departments = [
            ('LAW', 'Department of Law'),
            ('MHS', 'Department of Medical and Health Sciences'),
            ('NUR', 'Department of Nursing'),
            ('PH', 'Department of Public Health'),
            ('IT', 'Department of Information and Technology'),
            ('SE', 'Department of Social Engineering'),
            ('CS', 'Department of Cyber Security'),
            ('IR', 'Department of International Relations'),
            ('BA', 'Department of Business Administration'),
            ('MC', 'Department of Mass Communication'),
        ]
        
        created_count = 0
        
        for code, name in departments:
            department, created = Department.objects.get_or_create(
                code=code,
                defaults={
                    'name': name,
                    'description': f'{name} - Academic department offering specialized programs and courses.'
                }
            )
            
            if created:
                print(f"✓ Created: {code} - {name}")
                created_count += 1
            else:
                print(f"- Already exists: {code} - {name}")
        
        print(f"\n✓ Created {created_count} new departments")
        print(f"✓ Total departments: {Department.objects.count()}")
        
        print("\n" + "=" * 60)
        print("Departments Added Successfully!")
        print("=" * 60)
        print("All departments are now available for survey creation.")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
