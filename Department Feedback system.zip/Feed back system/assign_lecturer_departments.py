#!/usr/bin/env python
"""
Assign departments to existing lecturers
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("Assigning Departments to Lecturers")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from feedback.models import UserProfile, Department
        
        # Get departments
        cs_dept = Department.objects.filter(code='CS').first()
        it_dept = Department.objects.filter(code='IT').first()
        se_dept = Department.objects.filter(code='SE').first()
        
        # Assign departments to lecturers
        lecturer_assignments = [
            ('prof_smith', cs_dept),
            ('prof_johnson', it_dept if it_dept else cs_dept),
            ('dr_brown', se_dept if se_dept else cs_dept),
        ]
        
        for username, department in lecturer_assignments:
            try:
                profile = UserProfile.objects.get(user__username=username, user_type='lecturer')
                profile.department = department
                profile.save()
                print(f"✅ Assigned {username} to {department.code} - {department.name}")
            except UserProfile.DoesNotExist:
                print(f"❌ Lecturer {username} not found")
        
        print(f"\n✅ Lecturer department assignments completed!")
        print(f"Now lecturers can see surveys from their assigned departments.")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
