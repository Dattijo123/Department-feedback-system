#!/usr/bin/env python
"""
Check dashboard data accuracy
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        from feedback.models import UserProfile, Survey, Department
        
        print("📊 DASHBOARD DATA VERIFICATION")
        print("=" * 40)
        
        # User counts
        total_users = User.objects.count()
        students = UserProfile.objects.filter(user_type='student').count()
        lecturers = UserProfile.objects.filter(user_type='lecturer').count()
        admins = UserProfile.objects.filter(user_type='admin').count()
        
        print(f"👥 Total Users: {total_users}")
        print(f"🎓 Students: {students}")
        print(f"👨‍🏫 Lecturers: {lecturers}")
        print(f"🔧 Admins: {admins}")
        
        # Survey counts
        total_surveys = Survey.objects.count()
        active_surveys = Survey.objects.filter(is_active=True).count()
        
        print(f"📋 Total Surveys: {total_surveys}")
        print(f"✅ Active Surveys: {active_surveys}")
        
        # Recent users
        recent_users = User.objects.order_by('-date_joined')[:5]
        print(f"🕒 Recent Users: {len(recent_users)}")
        for user in recent_users:
            profile = UserProfile.objects.get(user=user)
            print(f"   - {user.username} ({profile.user_type})")
        
        # Departments
        departments = Department.objects.count()
        print(f"🏢 Departments: {departments}")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
