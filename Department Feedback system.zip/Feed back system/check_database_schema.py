#!/usr/bin/env python
"""
Check database schema and identify missing tables
"""

import os
import sys
import django
import sqlite3

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("DATABASE SCHEMA ANALYSIS")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        from django.conf import settings
        from django.db import connection
        
        # Get database path
        db_path = settings.DATABASES['default']['NAME']
        print(f"Database path: {db_path}")
        
        # Connect to SQLite database directly
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        
        print(f"\n📋 EXISTING TABLES ({len(tables)}):")
        print("-" * 40)
        feedback_tables = []
        for table in sorted(tables):
            table_name = table[0]
            print(f"  {table_name}")
            if table_name.startswith('feedback_'):
                feedback_tables.append(table_name)
        
        print(f"\n🎯 FEEDBACK APP TABLES ({len(feedback_tables)}):")
        print("-" * 40)
        for table in feedback_tables:
            print(f"  ✅ {table}")
        
        # Check for the missing table
        missing_table = 'feedback_courseassignment_students'
        if missing_table in [t[0] for t in tables]:
            print(f"\n✅ {missing_table} EXISTS")
        else:
            print(f"\n❌ {missing_table} MISSING")
        
        # Check CourseAssignment table
        courseassignment_table = 'feedback_courseassignment'
        if courseassignment_table in [t[0] for t in tables]:
            print(f"✅ {courseassignment_table} EXISTS")
        else:
            print(f"❌ {courseassignment_table} MISSING")
        
        conn.close()
        
        # Check Django models
        print(f"\n🔍 DJANGO MODEL ANALYSIS:")
        print("-" * 40)
        
        from feedback.models import CourseAssignment
        print(f"✅ CourseAssignment model found in models.py")
        
        # Check ManyToManyField
        students_field = CourseAssignment._meta.get_field('students')
        print(f"✅ students field: {students_field}")
        print(f"   Field type: {type(students_field)}")
        print(f"   Related model: {students_field.related_model}")
        print(f"   Through table: {students_field.m2m_db_table()}")
        
        # Check if migrations are needed
        print(f"\n🔧 MIGRATION STATUS:")
        print("-" * 40)
        
        from django.core.management import execute_from_command_line
        import io
        import contextlib
        
        # Capture makemigrations output
        f = io.StringIO()
        with contextlib.redirect_stdout(f):
            try:
                execute_from_command_line(['manage.py', 'makemigrations', 'feedback', '--dry-run'])
                output = f.getvalue()
                if 'No changes detected' in output:
                    print("✅ No pending migrations")
                else:
                    print("❌ Pending migrations detected:")
                    print(output)
            except Exception as e:
                print(f"Error checking migrations: {e}")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
