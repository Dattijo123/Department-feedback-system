#!/usr/bin/env python
"""
Sample data creation script for Department Feedback System
Run this after setting up the database to populate with test data
"""

import os
import sys
import django
from datetime import datetime, timedelta
from django.utils import timezone

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')
django.setup()

from feedback.models import (
    CustomUser, Department, Course, Lecturer, CourseAssignment,
    Survey, Question, QuestionChoice
)

def create_sample_data():
    print("Creating sample data for Department Feedback System...")
    
    # Create Departments
    print("Creating departments...")
    dept_cs = Department.objects.get_or_create(
        code="CS",
        defaults={
            "name": "Computer Science",
            "description": "Department of Computer Science and Engineering"
        }
    )[0]
    
    dept_math = Department.objects.get_or_create(
        code="MATH",
        defaults={
            "name": "Mathematics",
            "description": "Department of Mathematics"
        }
    )[0]
    
    dept_phys = Department.objects.get_or_create(
        code="PHYS",
        defaults={
            "name": "Physics",
            "description": "Department of Physics"
        }
    )[0]
    
    # Create Admin User
    print("Creating admin user...")
    admin_user = CustomUser.objects.get_or_create(
        username="admin",
        defaults={
            "email": "admin@university.edu",
            "first_name": "System",
            "last_name": "Administrator",
            "role": "admin",
            "is_staff": True,
            "is_superuser": True,
            "is_verified": True,
            "department": dept_cs
        }
    )[0]
    if not admin_user.has_usable_password():
        admin_user.set_password("admin123")
        admin_user.save()
    
    # Create Sample Students
    print("Creating sample students...")
    students = []
    for i in range(1, 6):
        student = CustomUser.objects.get_or_create(
            username=f"student{i}",
            defaults={
                "email": f"student{i}@university.edu",
                "first_name": f"Student",
                "last_name": f"User{i}",
                "role": "student",
                "student_id": f"STU{2024000 + i}",
                "is_verified": True,
                "department": dept_cs if i <= 3 else dept_math
            }
        )[0]
        if not student.has_usable_password():
            student.set_password("student123")
            student.save()
        students.append(student)
    
    # Create Sample Lecturers
    print("Creating sample lecturers...")
    lecturer_user = CustomUser.objects.get_or_create(
        username="drsmith",
        defaults={
            "email": "drsmith@university.edu",
            "first_name": "John",
            "last_name": "Smith",
            "role": "lecturer",
            "is_verified": True,
            "department": dept_cs
        }
    )[0]
    if not lecturer_user.has_usable_password():
        lecturer_user.set_password("lecturer123")
        lecturer_user.save()
    
    lecturer = Lecturer.objects.get_or_create(
        user=lecturer_user,
        defaults={
            "employee_id": "EMP001",
            "title": "Dr."
        }
    )[0]
    
    # Create Sample Courses
    print("Creating sample courses...")
    course1 = Course.objects.get_or_create(
        code="CS101",
        semester="fall",
        year=2024,
        defaults={
            "name": "Introduction to Programming",
            "department": dept_cs,
            "credits": 3
        }
    )[0]
    
    course2 = Course.objects.get_or_create(
        code="CS201",
        semester="fall",
        year=2024,
        defaults={
            "name": "Data Structures and Algorithms",
            "department": dept_cs,
            "credits": 4
        }
    )[0]
    
    course3 = Course.objects.get_or_create(
        code="MATH101",
        semester="fall",
        year=2024,
        defaults={
            "name": "Calculus I",
            "department": dept_math,
            "credits": 3
        }
    )[0]
    
    # Assign lecturer to courses
    CourseAssignment.objects.get_or_create(
        lecturer=lecturer,
        course=course1
    )
    CourseAssignment.objects.get_or_create(
        lecturer=lecturer,
        course=course2
    )
    
    # Create Sample Surveys
    print("Creating sample surveys...")
    
    # Course Evaluation Survey
    survey1 = Survey.objects.get_or_create(
        title="CS101 - Introduction to Programming Evaluation",
        defaults={
            "description": "Please evaluate your experience with the Introduction to Programming course.",
            "survey_type": "course",
            "course": course1,
            "lecturer": lecturer,
            "department": dept_cs,
            "is_active": True,
            "start_date": timezone.now() - timedelta(days=7),
            "end_date": timezone.now() + timedelta(days=30),
            "created_by": admin_user
        }
    )[0]
    
    # Lecturer Evaluation Survey
    survey2 = Survey.objects.get_or_create(
        title="Dr. Smith Teaching Evaluation",
        defaults={
            "description": "Please evaluate Dr. Smith's teaching effectiveness and methods.",
            "survey_type": "lecturer",
            "lecturer": lecturer,
            "department": dept_cs,
            "is_active": True,
            "start_date": timezone.now() - timedelta(days=5),
            "end_date": timezone.now() + timedelta(days=25),
            "created_by": admin_user
        }
    )[0]
    
    # Department Services Survey
    survey3 = Survey.objects.get_or_create(
        title="Computer Science Department Services Feedback",
        defaults={
            "description": "Help us improve our department services and facilities.",
            "survey_type": "department",
            "department": dept_cs,
            "is_active": True,
            "start_date": timezone.now() - timedelta(days=3),
            "end_date": timezone.now() + timedelta(days=45),
            "created_by": admin_user
        }
    )[0]
    
    # Create Sample Questions
    print("Creating sample questions...")
    
    # Questions for Course Evaluation
    q1 = Question.objects.get_or_create(
        survey=survey1,
        order=1,
        defaults={
            "text": "How would you rate the overall quality of this course?",
            "question_type": "rating",
            "is_required": True
        }
    )[0]
    
    q2 = Question.objects.get_or_create(
        survey=survey1,
        order=2,
        defaults={
            "text": "What did you like most about this course?",
            "question_type": "text",
            "is_required": False
        }
    )[0]
    
    q3 = Question.objects.get_or_create(
        survey=survey1,
        order=3,
        defaults={
            "text": "Would you recommend this course to other students?",
            "question_type": "yes_no",
            "is_required": True
        }
    )[0]
    
    # Questions for Lecturer Evaluation
    q4 = Question.objects.get_or_create(
        survey=survey2,
        order=1,
        defaults={
            "text": "How would you rate the instructor's teaching effectiveness?",
            "question_type": "rating",
            "is_required": True
        }
    )[0]
    
    q5 = Question.objects.get_or_create(
        survey=survey2,
        order=2,
        defaults={
            "text": "How clear were the instructor's explanations?",
            "question_type": "multiple_choice",
            "is_required": True
        }
    )[0]
    
    # Create choices for multiple choice question
    choices = [
        ("very_clear", "Very Clear"),
        ("clear", "Clear"),
        ("somewhat_clear", "Somewhat Clear"),
        ("unclear", "Unclear"),
        ("very_unclear", "Very Unclear")
    ]
    
    for i, (value, text) in enumerate(choices):
        QuestionChoice.objects.get_or_create(
            question=q5,
            value=value,
            defaults={
                "text": text,
                "order": i + 1
            }
        )
    
    # Questions for Department Services
    q6 = Question.objects.get_or_create(
        survey=survey3,
        order=1,
        defaults={
            "text": "How satisfied are you with the department's administrative services?",
            "question_type": "rating",
            "is_required": True
        }
    )[0]
    
    q7 = Question.objects.get_or_create(
        survey=survey3,
        order=2,
        defaults={
            "text": "What improvements would you suggest for our department?",
            "question_type": "text",
            "is_required": False
        }
    )[0]
    
    print("\n" + "="*50)
    print("Sample data created successfully!")
    print("="*50)
    print("\nTest Accounts Created:")
    print("Admin: username='admin', password='admin123'")
    print("Students: username='student1-5', password='student123'")
    print("Lecturer: username='drsmith', password='lecturer123'")
    print("\nYou can now:")
    print("1. Run: python manage.py runserver")
    print("2. Visit: http://localhost:8000")
    print("3. Login with any of the test accounts")
    print("4. Test the feedback system!")

if __name__ == "__main__":
    create_sample_data()
