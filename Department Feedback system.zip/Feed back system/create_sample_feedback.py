#!/usr/bin/env python
"""
Create sample feedback data for testing the analytics system
"""

import os
import sys
import django
import random

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("Creating Sample Feedback Data for Analytics Testing")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        from feedback.models import Survey, Question, QuestionChoice, FeedbackSubmission, FeedbackResponse, UserProfile
        
        # Get active surveys
        active_surveys = Survey.objects.filter(is_active=True)
        if not active_surveys.exists():
            print("❌ No active surveys found. Please create a survey first.")
            return
        
        # Get students
        students = User.objects.filter(userprofile__user_type='student')
        if not students.exists():
            print("❌ No students found. Please create student accounts first.")
            return
        
        print(f"Found {active_surveys.count()} active surveys and {students.count()} students")
        
        # Create sample feedback for each survey
        for survey in active_surveys:
            print(f"\nCreating feedback for: {survey.title}")
            
            questions = Question.objects.filter(survey=survey).order_by('order')
            if not questions.exists():
                print(f"  ❌ No questions found for survey {survey.id}")
                continue
            
            # Create feedback from 3-5 random students
            sample_students = random.sample(list(students), min(5, len(students)))
            
            for student in sample_students:
                # Check if student already submitted feedback
                student_hash = FeedbackSubmission.create_student_hash(student.id, survey.id)
                if FeedbackSubmission.objects.filter(student_hash=student_hash, survey=survey).exists():
                    print(f"  - {student.username} already submitted feedback")
                    continue
                
                # Create submission
                submission = FeedbackSubmission.objects.create(
                    survey=survey,
                    student_hash=student_hash,
                    ip_address='127.0.0.1'
                )
                
                # Create responses for each question
                for question in questions:
                    if question.question_type == 'rating':
                        # Random rating 1-5, weighted towards higher ratings
                        rating = random.choices([1, 2, 3, 4, 5], weights=[5, 10, 20, 35, 30])[0]
                        FeedbackResponse.objects.create(
                            submission=submission,
                            question=question,
                            rating_value=rating
                        )
                    
                    elif question.question_type == 'yes_no':
                        # Random yes/no, weighted towards yes
                        choice = random.choices(['yes', 'no'], weights=[70, 30])[0]
                        FeedbackResponse.objects.create(
                            submission=submission,
                            question=question,
                            choice_value=choice
                        )
                    
                    elif question.question_type == 'multiple_choice':
                        # Random choice from available options
                        choices = QuestionChoice.objects.filter(question=question)
                        if choices.exists():
                            choice = random.choice(choices)
                            FeedbackResponse.objects.create(
                                submission=submission,
                                question=question,
                                choice_value=choice.value
                            )
                    
                    elif question.question_type == 'text':
                        # Sample text responses
                        sample_texts = [
                            "Great course! Really enjoyed the practical exercises.",
                            "The content was well-structured and easy to follow.",
                            "Could use more hands-on examples.",
                            "Excellent teaching methods and clear explanations.",
                            "Would recommend adding more interactive sessions.",
                            "The course materials were very helpful.",
                            "Good pace and comprehensive coverage of topics.",
                            "Some sections could be explained in more detail.",
                            "Overall a very valuable learning experience.",
                            "The instructor was knowledgeable and helpful."
                        ]
                        
                        # 70% chance of providing text response
                        if random.random() < 0.7:
                            text = random.choice(sample_texts)
                            FeedbackResponse.objects.create(
                                submission=submission,
                                question=question,
                                text_value=text
                            )
                
                print(f"  ✅ Created feedback from {student.username}")
        
        print("\n" + "=" * 60)
        print("🎉 Sample Feedback Data Created Successfully!")
        print("=" * 60)
        
        # Show summary
        total_submissions = FeedbackSubmission.objects.count()
        total_responses = FeedbackResponse.objects.count()
        
        print(f"📊 Summary:")
        print(f"   Total Submissions: {total_submissions}")
        print(f"   Total Responses: {total_responses}")
        
        print(f"\n🧪 Testing URLs:")
        print(f"   Admin Dashboard: http://localhost:8000/admin-dashboard/")
        print(f"   Lecturer Dashboard: http://localhost:8000/lecturer-dashboard/")
        print(f"   View All Surveys: http://localhost:8000/view-all-surveys/")
        
        for survey in active_surveys:
            feedback_count = FeedbackSubmission.objects.filter(survey=survey).count()
            if feedback_count > 0:
                print(f"   Survey {survey.id} Results (Admin): http://localhost:8000/admin/survey/{survey.id}/results/")
                print(f"   Survey {survey.id} Results (Lecturer): http://localhost:8000/lecturer/survey/{survey.id}/results/")
        
        print(f"\n🎯 Test Accounts:")
        print(f"   Admin: admin / admin123")
        print(f"   Lecturer: prof_smith / prof123")
        print(f"   Student: test_student / student123")
        
        print(f"\n✅ Phase 5 Analytics System Ready for Testing!")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
