#!/usr/bin/env python
"""
Create a test survey for testing the question management system
"""

import os
import sys
import django
from datetime import datetime, timedelta

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("Creating Test Survey for Question Management Testing")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        from feedback.models import Department, Survey
        from django.utils import timezone
        
        # Get admin user
        admin_user = User.objects.filter(is_staff=True).first()
        if not admin_user:
            print("❌ No admin user found. Please create an admin user first.")
            return
        
        # Get a department
        department = Department.objects.filter(code='CS').first()
        if not department:
            department = Department.objects.first()
        
        if not department:
            print("❌ No departments found. Please run add_departments.py first.")
            return
        
        # Create test survey
        survey = Survey.objects.create(
            title="Course Evaluation Survey - Test",
            description="This is a test survey for demonstrating the question management system. Students can provide feedback on course content, teaching methods, and overall satisfaction.",
            survey_type="course_evaluation",
            department=department,
            created_by=admin_user,
            start_date=timezone.now(),
            end_date=timezone.now() + timedelta(days=30),
            is_active=False  # Keep as draft for testing
        )
        
        print(f"✅ Test survey created successfully!")
        print(f"   Survey ID: {survey.id}")
        print(f"   Title: {survey.title}")
        print(f"   Department: {department.name}")
        print(f"   Created by: {admin_user.username}")
        
        print("\n" + "=" * 60)
        print("🧪 TESTING INSTRUCTIONS:")
        print("=" * 60)
        print("1. Go to: http://localhost:8000/view-all-surveys/")
        print("2. Find the 'Course Evaluation Survey - Test' in the list")
        print("3. Click the 'Manage Questions' button (list icon)")
        print("4. Test adding different question types:")
        print("   - Rating Scale: 'How would you rate the course content?'")
        print("   - Text Response: 'What improvements would you suggest?'")
        print("   - Multiple Choice: 'Which teaching method was most effective?'")
        print("   - Yes/No: 'Would you recommend this course to others?'")
        print("5. Test editing and deleting questions")
        print("6. Test the survey preview functionality")
        
        print("\n📋 QUESTION MANAGEMENT URLS:")
        print(f"   Manage Questions: http://localhost:8000/survey/{survey.id}/questions/")
        print(f"   Add Question: http://localhost:8000/survey/{survey.id}/add-question/")
        print(f"   Preview Survey: http://localhost:8000/survey/{survey.id}/preview/")
        
        print("\n🎯 FEATURES TO TEST:")
        print("   ✅ Question creation with all 4 types")
        print("   ✅ Multiple choice options management")
        print("   ✅ Required/Optional question settings")
        print("   ✅ Question editing and deletion")
        print("   ✅ Survey preview functionality")
        print("   ✅ Question ordering and display")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
