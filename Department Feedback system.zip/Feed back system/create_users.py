#!/usr/bin/env python
"""
Create different user types for the feedback system
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("Creating Different User Types for Central Login")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        
        # User data: (username, password, email, is_staff, is_superuser, first_name, last_name)
        users_to_create = [
            # Admin Users
            ('admin', 'admin123', 'admin@university.edu', True, True, 'System', 'Administrator'),
            ('dept_admin', 'dept123', 'dept.admin@university.edu', True, False, 'Department', 'Admin'),
            
            # Lecturer Users
            ('prof_smith', 'prof123', 'smith@university.edu', False, False, 'John', 'Smith'),
            ('prof_johnson', 'prof123', 'johnson@university.edu', False, False, 'Sarah', 'Johnson'),
            ('dr_brown', 'prof123', 'brown@university.edu', False, False, 'Michael', 'Brown'),
            
            # Student Users
            ('student1', 'student123', 'student1@university.edu', False, False, 'Alice', 'Wilson'),
            ('student2', 'student123', 'student2@university.edu', False, False, 'Bob', 'Davis'),
            ('student3', 'student123', 'student3@university.edu', False, False, 'Carol', 'Miller'),
        ]
        
        print("Creating users...")
        created_count = 0
        
        for username, password, email, is_staff, is_superuser, first_name, last_name in users_to_create:
            if not User.objects.filter(username=username).exists():
                user = User.objects.create_user(
                    username=username,
                    password=password,
                    email=email,
                    first_name=first_name,
                    last_name=last_name,
                    is_staff=is_staff,
                    is_superuser=is_superuser
                )
                created_count += 1
                user_type = "Admin" if is_staff else "Lecturer/Student"
                print(f"✓ Created {user_type}: {username} / {password}")
            else:
                print(f"- User already exists: {username}")
        
        print(f"\n✓ Created {created_count} new users")
        
        print("\n" + "=" * 60)
        print("CENTRAL LOGIN CREDENTIALS")
        print("=" * 60)
        print("\n🔑 ADMIN USERS (Access to Dashboard & Admin Panel):")
        print("   Username: admin          Password: admin123")
        print("   Username: dept_admin     Password: dept123")
        
        print("\n👨‍🏫 LECTURER USERS (Future: Course Management):")
        print("   Username: prof_smith     Password: prof123")
        print("   Username: prof_johnson   Password: prof123")
        print("   Username: dr_brown       Password: prof123")
        
        print("\n🎓 STUDENT USERS (Future: Survey Submission):")
        print("   Username: student1       Password: student123")
        print("   Username: student2       Password: student123")
        print("   Username: student3       Password: student123")
        
        print("\n" + "=" * 60)
        print("All users can login at: http://localhost:8000")
        print("Same login page, different access based on user type!")
        print("=" * 60)
        
    except Exception as e:
        print(f"Error: {e}")
        print("Please check your Django installation and try again.")

if __name__ == "__main__":
    main()
