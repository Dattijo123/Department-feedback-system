#!/usr/bin/env python
"""
Debug survey submission issues
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("DEBUGGING SURVEY SUBMISSION ISSUES")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        from feedback.models import Survey, Question, QuestionChoice, FeedbackSubmission, FeedbackResponse
        
        print("1. CHECKING ACTIVE SURVEYS:")
        print("-" * 40)
        active_surveys = Survey.objects.filter(is_active=True)
        for survey in active_surveys:
            print(f"📋 Survey ID: {survey.id}")
            print(f"   Title: {survey.title}")
            print(f"   Department: {survey.department.code}")
            print(f"   Questions: {survey.questions.count()}")
            print(f"   Active: {survey.is_active}")
            print(f"   End Date: {survey.end_date}")
            print()
        
        if not active_surveys.exists():
            print("❌ No active surveys found!")
            return
        
        # Get the first active survey for testing
        test_survey = active_surveys.first()
        print(f"2. ANALYZING SURVEY: {test_survey.title}")
        print("-" * 40)
        
        questions = Question.objects.filter(survey=test_survey).order_by('order')
        print(f"Total Questions: {questions.count()}")
        
        for question in questions:
            print(f"Q{question.order}: {question.text[:50]}...")
            print(f"   Type: {question.question_type}")
            print(f"   Required: {question.is_required}")
            
            if question.question_type == 'multiple_choice':
                choices = QuestionChoice.objects.filter(question=question)
                print(f"   Choices: {choices.count()}")
                for choice in choices:
                    print(f"     - {choice.text} (value: {choice.value})")
            print()
        
        print("3. CHECKING SUBMISSION PROCESS:")
        print("-" * 40)
        
        # Test student
        test_student = User.objects.filter(username='test_student').first()
        if not test_student:
            print("❌ Test student not found!")
            return
        
        print(f"Test Student: {test_student.username}")
        
        # Check if student has already submitted
        from feedback.models import FeedbackSubmission
        student_hash = FeedbackSubmission.create_student_hash(test_student.id, test_survey.id)
        existing_submission = FeedbackSubmission.objects.filter(
            student_hash=student_hash, 
            survey=test_survey
        ).first()
        
        if existing_submission:
            print(f"⚠️  Student has already submitted this survey!")
            print(f"   Submission ID: {existing_submission.id}")
            print(f"   Submitted at: {existing_submission.submitted_at}")
            
            # Show responses
            responses = FeedbackResponse.objects.filter(submission=existing_submission)
            print(f"   Responses: {responses.count()}")
            for response in responses:
                print(f"     Q{response.question.order}: ", end="")
                if response.rating_value:
                    print(f"Rating: {response.rating_value}")
                elif response.text_value:
                    print(f"Text: {response.text_value[:30]}...")
                elif response.choice_value:
                    print(f"Choice: {response.choice_value}")
                else:
                    print("No value")
        else:
            print("✅ Student has not submitted this survey yet")
        
        print("\n4. TESTING FORM VALIDATION:")
        print("-" * 40)
        
        # Simulate form data
        sample_responses = {}
        validation_errors = []
        
        for question in questions:
            field_name = f'question_{question.id}'
            
            if question.question_type == 'rating':
                sample_responses[field_name] = '4'  # Valid rating
            elif question.question_type == 'yes_no':
                sample_responses[field_name] = 'yes'  # Valid yes/no
            elif question.question_type == 'text':
                sample_responses[field_name] = 'This is a sample text response'
            elif question.question_type == 'multiple_choice':
                choices = QuestionChoice.objects.filter(question=question)
                if choices.exists():
                    sample_responses[field_name] = choices.first().value
                else:
                    validation_errors.append(f"No choices found for question {question.order}")
        
        print("Sample form data:")
        for field, value in sample_responses.items():
            print(f"  {field}: {value}")
        
        if validation_errors:
            print("\n❌ Validation Errors Found:")
            for error in validation_errors:
                print(f"  - {error}")
        else:
            print("\n✅ Sample data looks valid")
        
        print("\n5. CHECKING MULTIPLE CHOICE QUESTIONS:")
        print("-" * 40)
        
        mc_questions = questions.filter(question_type='multiple_choice')
        for question in mc_questions:
            choices = QuestionChoice.objects.filter(question=question)
            print(f"Q{question.order}: {question.text[:40]}...")
            print(f"  Choices in DB: {choices.count()}")
            for choice in choices:
                print(f"    ID: {choice.id}, Text: '{choice.text}', Value: '{choice.value}'")
            
            # Check if values match what might be submitted
            if choices.exists():
                test_value = choices.first().value
                exists = QuestionChoice.objects.filter(question=question, value=test_value).exists()
                print(f"  Validation test for '{test_value}': {'✅ PASS' if exists else '❌ FAIL'}")
            print()
        
        print("6. DEBUGGING RECOMMENDATIONS:")
        print("-" * 40)
        print("✅ Check browser console for JavaScript errors")
        print("✅ Verify all required fields are filled")
        print("✅ Check that multiple choice values match database")
        print("✅ Ensure CSRF token is present in form")
        print("✅ Check Django logs for server errors")
        
        print(f"\n🧪 TEST SURVEY SUBMISSION URL:")
        print(f"http://localhost:8000/survey/{test_survey.id}/take/")
        
        print(f"\n🔧 MANUAL TESTING STEPS:")
        print("1. Login as test_student / student123")
        print("2. Go to survey URL above")
        print("3. Fill out all required questions")
        print("4. Check browser console for errors")
        print("5. Click submit and watch for error messages")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
