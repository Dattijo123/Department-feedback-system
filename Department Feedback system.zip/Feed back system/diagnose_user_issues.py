#!/usr/bin/env python
"""
Diagnose user creation and authentication issues
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("DIAGNOSING USER CREATION & AUTHENTICATION ISSUES")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        from feedback.models import UserProfile, Department
        
        print("1. CHECKING EXISTING USERS:")
        print("-" * 40)
        users = User.objects.all().order_by('username')
        for user in users:
            try:
                profile = UserProfile.objects.get(user=user)
                print(f"✅ {user.username} | {profile.user_type} | {profile.department.code if profile.department else 'No Dept'} | Active: {user.is_active}")
            except UserProfile.DoesNotExist:
                print(f"❌ {user.username} | NO PROFILE | Active: {user.is_active}")
        
        print(f"\nTotal Users: {users.count()}")
        
        print("\n2. CHECKING DEPARTMENTS:")
        print("-" * 40)
        departments = Department.objects.all().order_by('code')
        for dept in departments:
            student_count = UserProfile.objects.filter(department=dept, user_type='student').count()
            print(f"📁 {dept.code} - {dept.name} | Students: {student_count}")
        
        print("\n3. CHECKING STUDENT USERS:")
        print("-" * 40)
        student_profiles = UserProfile.objects.filter(user_type='student')
        print(f"Total Student Profiles: {student_profiles.count()}")
        
        for profile in student_profiles:
            print(f"🎓 {profile.user.username} | {profile.student_id} | {profile.department.code if profile.department else 'No Dept'}")
        
        print("\n4. TESTING AUTHENTICATION:")
        print("-" * 40)
        from django.contrib.auth import authenticate
        
        test_users = ['student1', 'student2', 'student3', 'test_student']
        test_password = 'student123'
        
        for username in test_users:
            user = authenticate(username=username, password=test_password)
            if user:
                print(f"✅ {username} authentication: SUCCESS")
            else:
                print(f"❌ {username} authentication: FAILED")
        
        print("\n5. CHECKING USER CREATION PROCESS:")
        print("-" * 40)
        
        # Test creating a user
        test_username = 'debug_student'
        if User.objects.filter(username=test_username).exists():
            User.objects.filter(username=test_username).delete()
            print(f"🗑️  Removed existing {test_username}")
        
        # Create test user
        test_user = User.objects.create_user(
            username=test_username,
            email='debug@test.edu',
            password='debug123',
            first_name='Debug',
            last_name='Student'
        )
        
        # Create profile
        cs_dept = Department.objects.filter(code='CS').first()
        profile = UserProfile.objects.create(
            user=test_user,
            user_type='student',
            department=cs_dept,
            student_id=f"STU_{test_user.id:04d}"
        )
        
        print(f"✅ Created test user: {test_username}")
        print(f"✅ Created profile: {profile.user_type} in {profile.department.code}")
        
        # Test authentication
        auth_user = authenticate(username=test_username, password='debug123')
        if auth_user:
            print(f"✅ Authentication test: SUCCESS")
        else:
            print(f"❌ Authentication test: FAILED")
        
        print("\n" + "=" * 60)
        print("🎯 STUDENT DASHBOARD ACCESS INSTRUCTIONS:")
        print("=" * 60)
        print("1. STUDENT LOGIN CREDENTIALS:")
        print("   Username: test_student")
        print("   Password: student123")
        print("   OR")
        print("   Username: debug_student")
        print("   Password: debug123")
        print()
        print("2. LOGIN PROCESS:")
        print("   Step 1: Go to http://localhost:8000/")
        print("   Step 2: Click 'Login' or go to http://localhost:8000/login/")
        print("   Step 3: Enter student credentials")
        print("   Step 4: After login, you should be redirected to:")
        print("           http://localhost:8000/student-dashboard/")
        print()
        print("3. DIRECT URLS:")
        print("   - Login Page: http://localhost:8000/login/")
        print("   - Student Dashboard: http://localhost:8000/student-dashboard/")
        print("   - Student Surveys: http://localhost:8000/student-surveys/")
        print()
        print("4. EXPECTED BEHAVIOR:")
        print("   ✅ Login redirects to student dashboard")
        print("   ✅ Dashboard shows pending surveys")
        print("   ✅ Can navigate to survey list")
        print("   ✅ Can take surveys")
        
        print("\n🔧 TROUBLESHOOTING RECOMMENDATIONS:")
        print("=" * 60)
        if student_profiles.count() == 0:
            print("❌ NO STUDENT PROFILES FOUND!")
            print("   Run: python setup_student_survey_test.py")
        else:
            print("✅ Student profiles exist")
        
        if departments.count() == 0:
            print("❌ NO DEPARTMENTS FOUND!")
            print("   Run: python update_departments.py")
        else:
            print("✅ Departments configured")
        
        # Clean up test user
        test_user.delete()
        print(f"\n🗑️  Cleaned up test user: {test_username}")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
