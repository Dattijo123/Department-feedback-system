from django.contrib import admin

# Temporarily using default Django admin - custom models will be added later
