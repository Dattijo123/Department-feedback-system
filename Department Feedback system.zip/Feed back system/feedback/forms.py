from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.core.validators import EmailValidator
from .models import CustomUser, StudentVerification, FeedbackResponse, Question
import hashlib
import secrets

class StudentRegistrationForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        validators=[EmailValidator()],
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter your university email'})
    )
    student_id = forms.CharField(
        max_length=20,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your student ID'})
    )
    first_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'First Name'})
    )
    last_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Last Name'})
    )

    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'student_id', 'first_name', 'last_name', 'password1', 'password2')
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Choose a username'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Password'})
        self.fields['password2'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Confirm Password'})

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if CustomUser.objects.filter(email=email).exists():
            raise forms.ValidationError("This email is already registered.")
        return email

    def clean_student_id(self):
        student_id = self.cleaned_data.get('student_id')
        if CustomUser.objects.filter(student_id=student_id).exists():
            raise forms.ValidationError("This student ID is already registered.")
        return student_id

class CustomLoginForm(AuthenticationForm):
    username = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username or Email'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password'})
    )

class StudentVerificationForm(forms.Form):
    verification_code = forms.CharField(
        max_length=6,
        min_length=6,
        widget=forms.TextInput(attrs={
            'class': 'form-control text-center',
            'placeholder': '000000',
            'style': 'font-size: 1.5rem; letter-spacing: 0.5rem;'
        })
    )

    def clean_verification_code(self):
        code = self.cleaned_data.get('verification_code')
        if not code.isdigit():
            raise forms.ValidationError("Verification code must contain only numbers.")
        return code

class FeedbackForm(forms.Form):
    def __init__(self, survey, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.survey = survey

        for question in survey.questions.all():
            field_name = f'question_{question.id}'

            if question.question_type == 'rating':
                self.fields[field_name] = forms.ChoiceField(
                    choices=[(i, str(i)) for i in range(1, 6)],
                    widget=forms.RadioSelect(attrs={'class': 'form-check-input'}),
                    required=question.is_required,
                    label=question.text,
                    help_text="Rate from 1 (Poor) to 5 (Excellent)"
                )
            elif question.question_type == 'text':
                self.fields[field_name] = forms.CharField(
                    widget=forms.Textarea(attrs={
                        'class': 'form-control',
                        'rows': 4,
                        'placeholder': 'Enter your detailed feedback here...'
                    }),
                    required=question.is_required,
                    label=question.text,
                    max_length=2000
                )
            elif question.question_type == 'multiple_choice':
                choices = [(choice.value, choice.text) for choice in question.choices.all()]
                self.fields[field_name] = forms.ChoiceField(
                    choices=choices,
                    widget=forms.RadioSelect(attrs={'class': 'form-check-input'}),
                    required=question.is_required,
                    label=question.text
                )
            elif question.question_type == 'yes_no':
                self.fields[field_name] = forms.ChoiceField(
                    choices=[('yes', 'Yes'), ('no', 'No')],
                    widget=forms.RadioSelect(attrs={'class': 'form-check-input'}),
                    required=question.is_required,
                    label=question.text
                )

    def clean(self):
        cleaned_data = super().clean()

        # Validate that all required questions are answered
        for question in self.survey.questions.filter(is_required=True):
            field_name = f'question_{question.id}'
            if not cleaned_data.get(field_name):
                self.add_error(field_name, 'This question is required.')

        return cleaned_data

def generate_student_hash(user):
    """Generate anonymous hash for student identification"""
    salt = "feedback_system_salt_2024"
    data = f"{user.student_id}_{user.email}_{salt}"
    return hashlib.sha256(data.encode()).hexdigest()

def generate_verification_code():
    """Generate 6-digit verification code"""
    return str(secrets.randbelow(900000) + 100000)
