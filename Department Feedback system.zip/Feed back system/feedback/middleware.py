from django.http import HttpResponseRedirect
from django.urls import reverse
from django.contrib import messages
from .models import FeedbackSubmission
from .forms import generate_student_hash

class DuplicateSubmissionMiddleware:
    """
    Middleware to prevent duplicate feedback submissions
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Check for duplicate submissions on feedback submission pages
        if (request.path.startswith('/submit/') and 
            request.user.is_authenticated and 
            request.user.role == 'student'):
            
            # Extract survey_id from URL
            try:
                survey_id = int(request.path.split('/')[2])
                student_hash = generate_student_hash(request.user)
                
                # Check if user already submitted feedback for this survey
                if FeedbackSubmission.objects.filter(
                    survey_id=survey_id, 
                    student_hash=student_hash
                ).exists():
                    messages.warning(
                        request, 
                        'You have already submitted feedback for this survey.'
                    )
                    return HttpResponseRedirect(reverse('feedback:survey_list'))
                    
            except (ValueError, IndexError):
                pass

        response = self.get_response(request)
        return response

class SecurityHeadersMiddleware:
    """
    Add security headers to responses
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        
        # Add security headers
        response['X-Content-Type-Options'] = 'nosniff'
        response['X-Frame-Options'] = 'DENY'
        response['X-XSS-Protection'] = '1; mode=block'
        response['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        
        return response
