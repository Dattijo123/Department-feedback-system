from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import hashlib

# Department and Course Models
class Department(models.Model):
    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=10, unique=True)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.code} - {self.name}"

class Course(models.Model):
    SEMESTER_CHOICES = [
        ('fall', 'Fall'),
        ('spring', 'Spring'),
        ('summer', 'Summer'),
    ]

    name = models.CharField(max_length=100)
    code = models.CharField(max_length=20)
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    semester = models.CharField(max_length=10, choices=SEMESTER_CHOICES)
    year = models.IntegerField()
    credits = models.IntegerField(default=3)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['code', 'semester', 'year']

    def __str__(self):
        return f"{self.code} - {self.name} ({self.semester} {self.year})"

# User Profile Extensions
class UserProfile(models.Model):
    USER_TYPES = [
        ('student', 'Student'),
        ('lecturer', 'Lecturer'),
        ('admin', 'Admin'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    user_type = models.CharField(max_length=20, choices=USER_TYPES, default='student')
    student_id = models.CharField(max_length=20, unique=True, null=True, blank=True)
    employee_id = models.CharField(max_length=20, unique=True, null=True, blank=True)
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} ({self.user_type})"

# Survey Models
class Survey(models.Model):
    SURVEY_TYPES = [
        ('course', 'Course Evaluation'),
        ('lecturer', 'Lecturer Evaluation'),
    ]

    title = models.CharField(max_length=200)
    description = models.TextField()
    survey_type = models.CharField(max_length=20, choices=SURVEY_TYPES)
    course = models.ForeignKey(Course, on_delete=models.CASCADE, null=True, blank=True)
    lecturer = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='lecturer_surveys')
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_surveys')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.survey_type})"

    def is_open(self):
        now = timezone.now()
        return self.is_active and self.start_date <= now <= self.end_date

# Question Models
class Question(models.Model):
    QUESTION_TYPES = [
        ('rating', 'Rating Scale (1-5)'),
        ('text', 'Text Response'),
        ('multiple_choice', 'Multiple Choice'),
        ('yes_no', 'Yes/No'),
    ]

    survey = models.ForeignKey(Survey, on_delete=models.CASCADE, related_name='questions')
    text = models.TextField()
    question_type = models.CharField(max_length=20, choices=QUESTION_TYPES)
    is_required = models.BooleanField(default=True)
    order = models.IntegerField(default=0)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return f"Q{self.order}: {self.text[:50]}..."

class QuestionChoice(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='choices')
    text = models.CharField(max_length=200)
    value = models.CharField(max_length=50)
    order = models.IntegerField(default=0)

    class Meta:
        ordering = ['order']

    def __str__(self):
        return self.text

# Feedback Submission Models (Pseudonymous)
class FeedbackSubmission(models.Model):
    survey = models.ForeignKey(Survey, on_delete=models.CASCADE)
    student_hash = models.CharField(max_length=64)  # Hashed student identifier for pseudonymity
    submitted_at = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        unique_together = ['survey', 'student_hash']

    def __str__(self):
        return f"Submission for {self.survey.title} at {self.submitted_at}"

    @classmethod
    def create_student_hash(cls, user_id, survey_id):
        """Create a pseudonymous hash for the student"""
        data = f"{user_id}_{survey_id}_feedback_system"
        return hashlib.sha256(data.encode()).hexdigest()

class FeedbackResponse(models.Model):
    submission = models.ForeignKey(FeedbackSubmission, on_delete=models.CASCADE, related_name='responses')
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    rating_value = models.IntegerField(null=True, blank=True)  # For rating questions (1-5)
    text_value = models.TextField(null=True, blank=True)      # For text responses
    choice_value = models.CharField(max_length=50, null=True, blank=True)  # For multiple choice

    def __str__(self):
        return f"Response to {self.question.text[:30]}..."

# Course Assignment Model
class CourseAssignment(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    lecturer = models.ForeignKey(User, on_delete=models.CASCADE)
    students = models.ManyToManyField(User, related_name='enrolled_courses', blank=True)
    assigned_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['course', 'lecturer']

    def __str__(self):
        return f"{self.lecturer.username} - {self.course.code}"
