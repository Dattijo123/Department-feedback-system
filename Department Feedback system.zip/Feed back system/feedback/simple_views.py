from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from django.utils import timezone
from .models import Department, Course, Survey, Question, QuestionChoice, FeedbackSubmission, FeedbackResponse, UserProfile, CourseAssignment

def home(request):
    # If user is not authenticated, show login page
    if not request.user.is_authenticated:
        return render(request, 'feedback/simple_login.html')

    # If authenticated, redirect to dashboard
    return redirect('feedback:simple_dashboard')

def simple_login(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()

        print(f"DEBUG: Login attempt - Username: '{username}', Password provided: {bool(password)}")

        if not username or not password:
            messages.error(request, 'Please enter both username and password.')
            return render(request, 'feedback/simple_login.html')

        user = authenticate(request, username=username, password=password)
        print(f"DEBUG: Authentication result: {user}")

        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome back, {user.username}!')
            print(f"DEBUG: User logged in successfully, redirecting...")

            # Redirect based on user type
            if user.is_staff or user.is_superuser:
                return redirect('feedback:admin_dashboard')
            elif hasattr(user, 'is_lecturer') and user.is_lecturer:
                return redirect('feedback:lecturer_dashboard')
            else:
                return redirect('feedback:student_dashboard')
        else:
            messages.error(request, 'Invalid username or password. Please try again.')
            print(f"DEBUG: Authentication failed for username: {username}")

    return render(request, 'feedback/simple_login.html')

def simple_logout(request):
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('feedback:home')

@login_required
def admin_dashboard(request):
    # Only admin/staff can access
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    # Enhanced system-wide analytics
    total_users = User.objects.count()
    total_surveys = Survey.objects.count()
    active_surveys = Survey.objects.filter(is_active=True).count()
    completed_surveys = Survey.objects.filter(is_active=False).count()

    try:
        students = UserProfile.objects.filter(user_type='student').count()
        lecturers = UserProfile.objects.filter(user_type='lecturer').count()
        total_submissions = FeedbackSubmission.objects.count()
        total_responses = FeedbackResponse.objects.count()
    except:
        # Fallback if models don't work
        students = User.objects.filter(is_staff=False, is_superuser=False).count()
        lecturers = User.objects.filter(username__startswith='prof_').count() + User.objects.filter(username__startswith='dr_').count()
        total_submissions = 0
        total_responses = 0

    try:
        recent_feedback = FeedbackSubmission.objects.filter(
            submitted_at__gte=timezone.now() - timezone.timedelta(days=7)
        ).count()
    except:
        recent_feedback = 0

    # Department analytics
    department_stats = []
    try:
        departments = Department.objects.all()
        for dept in departments:
            dept_surveys = Survey.objects.filter(department=dept).count()
            dept_students = UserProfile.objects.filter(user_type='student', department=dept).count()
            dept_lecturers = UserProfile.objects.filter(user_type='lecturer', department=dept).count()
            dept_submissions = FeedbackSubmission.objects.filter(survey__department=dept).count()

            # Calculate response rate
            dept_response_rate = 0
            if dept_students > 0 and dept_surveys > 0:
                expected_responses = dept_students * dept_surveys
                dept_response_rate = (dept_submissions / expected_responses * 100) if expected_responses > 0 else 0

            department_stats.append({
                'department': dept,
                'surveys': dept_surveys,
                'students': dept_students,
                'lecturers': dept_lecturers,
                'submissions': dept_submissions,
                'response_rate': dept_response_rate
            })
    except:
        department_stats = []

    # Surveys with feedback for quick access
    surveys_with_feedback = []
    try:
        for survey in Survey.objects.all()[:20]:  # Limit to prevent performance issues
            feedback_count = FeedbackSubmission.objects.filter(survey=survey).count()
            if feedback_count > 0:
                surveys_with_feedback.append({
                    'survey': survey,
                    'feedback_count': feedback_count
                })
        surveys_with_feedback = sorted(surveys_with_feedback, key=lambda x: x['feedback_count'], reverse=True)[:10]
    except:
        surveys_with_feedback = []

    # Overall system response rate
    overall_response_rate = 0
    if students > 0 and total_surveys > 0:
        expected_total_responses = students * total_surveys
        overall_response_rate = (total_submissions / expected_total_responses * 100) if expected_total_responses > 0 else 0

    context = {
        'total_users': total_users,
        'total_surveys': total_surveys,
        'total_students': students,
        'total_lecturers': lecturers,
        'active_surveys': active_surveys,
        'completed_surveys': completed_surveys,
        'total_submissions': total_submissions,
        'total_responses': total_responses,
        'overall_response_rate': overall_response_rate,
        'recent_feedback': recent_feedback,
        'department_stats': department_stats,
        'surveys_with_feedback': surveys_with_feedback,
        'recent_users': User.objects.order_by('-date_joined')[:5],
        'current_user': request.user,
        'user_type': 'Admin'
    }
    return render(request, 'feedback/admin_dashboard.html', context)

@login_required
def lecturer_dashboard(request):
    # For now, allow any authenticated user (will add lecturer check later)
    context = {
        'current_user': request.user,
        'user_type': 'Lecturer',
        'assigned_courses': [],  # Will implement when we add courses
        'recent_feedback': 0,    # Will implement when we add feedback
        'average_rating': 0.0    # Will implement when we add ratings
    }
    return render(request, 'feedback/lecturer_dashboard.html', context)

@login_required
def student_dashboard(request):
    # Check if user is a student
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        if user_profile.user_type != 'student':
            # Redirect non-students to appropriate dashboard
            if user_profile.user_type == 'admin' or request.user.is_staff:
                return redirect('feedback:admin_dashboard')
            elif user_profile.user_type == 'lecturer':
                return redirect('feedback:lecturer_dashboard')
            else:
                messages.error(request, 'Access denied.')
                return redirect('feedback:home')
    except UserProfile.DoesNotExist:
        messages.error(request, 'User profile not found. Please contact administrator.')
        return redirect('feedback:home')

    # Get available surveys for student's department
    available_surveys = Survey.objects.filter(
        is_active=True,
        start_date__lte=timezone.now(),
        end_date__gte=timezone.now(),
        department=user_profile.department
    ).order_by('-created_at')

    # Get completed surveys by this student
    student_hash_prefix = FeedbackSubmission.create_student_hash(request.user.id, 0)[:32]
    completed_survey_ids = FeedbackSubmission.objects.filter(
        student_hash__startswith=student_hash_prefix
    ).values_list('survey_id', flat=True)

    # Separate pending and completed surveys
    pending_surveys = available_surveys.exclude(id__in=completed_survey_ids)
    completed_surveys_count = len(completed_survey_ids)

    # Get upcoming surveys (not yet started)
    upcoming_surveys = Survey.objects.filter(
        is_active=True,
        start_date__gt=timezone.now(),
        department=user_profile.department
    ).order_by('start_date')

    context = {
        'current_user': request.user,
        'user_profile': user_profile,
        'user_type': 'Student',
        'pending_surveys': pending_surveys[:5],  # Show latest 5
        'upcoming_surveys': upcoming_surveys[:3],  # Show next 3
        'pending_count': pending_surveys.count(),
        'completed_count': completed_surveys_count,
        'upcoming_count': upcoming_surveys.count(),
        'total_available': available_surveys.count(),
    }
    return render(request, 'feedback/student_dashboard.html', context)

# Keep the old simple_dashboard for backward compatibility
@login_required
def simple_dashboard(request):
    # Redirect to appropriate dashboard based on user type
    if request.user.is_staff or request.user.is_superuser:
        return redirect('feedback:admin_dashboard')
    elif hasattr(request.user, 'is_lecturer') and request.user.is_lecturer:
        return redirect('feedback:lecturer_dashboard')
    else:
        return redirect('feedback:student_dashboard')

# Survey Management Views
@login_required
def create_survey(request):
    # Only admin can create surveys
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        survey_type = request.POST.get('survey_type')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')

        if title and description and survey_type and start_date and end_date:
            # Get selected department or use default
            department_id = request.POST.get('department')
            if department_id:
                department = Department.objects.get(id=department_id)
            else:
                department = Department.objects.first()  # Use first available department

            survey = Survey.objects.create(
                title=title,
                description=description,
                survey_type=survey_type,
                department=department,
                start_date=start_date,
                end_date=end_date,
                created_by=request.user
            )

            messages.success(request, f'Survey "{title}" created successfully!')
            return redirect('feedback:admin_dashboard')
        else:
            messages.error(request, 'Please fill in all required fields.')

    context = {
        'survey_types': Survey.SURVEY_TYPES,
        'departments': Department.objects.all()
    }
    return render(request, 'feedback/create_survey.html', context)

@login_required
def view_all_surveys(request):
    # Only admin can view all surveys
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    surveys = Survey.objects.all().order_by('-created_at')

    context = {
        'surveys': surveys,
        'total_surveys': surveys.count(),
        'active_surveys': surveys.filter(is_active=True).count(),
        'inactive_surveys': surveys.filter(is_active=False).count(),
    }
    return render(request, 'feedback/view_all_surveys.html', context)

@login_required
def add_user(request):
    # Only admin can add users
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        user_type = request.POST.get('user_type')
        department_id = request.POST.get('department')

        if username and email and password and user_type:
            # Only allow lecturer and student creation
            if user_type not in ['lecturer', 'student']:
                messages.error(request, 'Invalid user type. Only lecturers and students can be created.')
                # Re-create context for error case
                allowed_user_types = [('lecturer', 'Lecturer'), ('student', 'Student')]
                context = {'departments': Department.objects.all(), 'user_types': allowed_user_types}
                return render(request, 'feedback/add_user.html', context)

            try:
                # Create user (never set is_staff=True for new users)
                user = User.objects.create_user(
                    username=username,
                    email=email,
                    password=password,
                    first_name=first_name,
                    last_name=last_name,
                    is_staff=False  # Only lecturers and students, no admin privileges
                )

                # Create user profile
                department = None
                if department_id:
                    department = Department.objects.get(id=department_id)

                UserProfile.objects.create(
                    user=user,
                    user_type=user_type,
                    department=department,
                    student_id=f"STU_{user.id:04d}" if user_type == 'student' else None,
                    employee_id=f"EMP_{user.id:04d}" if user_type in ['lecturer', 'admin'] else None
                )

                messages.success(request, f'User "{username}" created successfully!')
                return redirect('feedback:manage_users')

            except Exception as e:
                messages.error(request, f'Error creating user: {str(e)}')
        else:
            messages.error(request, 'Please fill in all required fields.')

    # Only allow creation of lecturers and students (no admin creation)
    allowed_user_types = [
        ('lecturer', 'Lecturer'),
        ('student', 'Student'),
    ]

    context = {
        'departments': Department.objects.all(),
        'user_types': allowed_user_types
    }
    return render(request, 'feedback/add_user.html', context)

@login_required
def manage_users(request):
    # Only admin can manage users
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    users = User.objects.all().order_by('-date_joined')

    context = {
        'users': users,
        'total_users': users.count(),
        'students': UserProfile.objects.filter(user_type='student').count(),
        'lecturers': UserProfile.objects.filter(user_type='lecturer').count(),
        'admins': UserProfile.objects.filter(user_type='admin').count(),
    }
    return render(request, 'feedback/manage_users.html', context)

@login_required
def edit_user(request, user_id):
    # Only admin can edit users
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        user = User.objects.get(id=user_id)
        profile = UserProfile.objects.get(user=user)
    except (User.DoesNotExist, UserProfile.DoesNotExist):
        messages.error(request, 'User not found.')
        return redirect('feedback:manage_users')

    # Prevent editing superuser accounts
    if user.is_superuser and not request.user.is_superuser:
        messages.error(request, 'Cannot edit superuser accounts.')
        return redirect('feedback:manage_users')

    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        user_type = request.POST.get('user_type')
        department_id = request.POST.get('department')
        is_active = request.POST.get('is_active') == 'on'

        if username and email and user_type:
            # Only allow lecturer and student editing
            if user_type not in ['lecturer', 'student']:
                messages.error(request, 'Invalid user type. Only lecturers and students can be edited.')
                return redirect('feedback:edit_user', user_id=user_id)

            try:
                # Update user
                user.username = username
                user.email = email
                user.first_name = first_name
                user.last_name = last_name
                user.is_active = is_active
                user.save()

                # Update profile
                profile.user_type = user_type
                if department_id:
                    profile.department = Department.objects.get(id=department_id)
                profile.save()

                messages.success(request, f'User "{username}" updated successfully!')
                return redirect('feedback:manage_users')

            except Exception as e:
                messages.error(request, f'Error updating user: {str(e)}')
        else:
            messages.error(request, 'Please fill in all required fields.')

    # Only allow lecturer and student editing
    allowed_user_types = [
        ('lecturer', 'Lecturer'),
        ('student', 'Student'),
    ]

    context = {
        'user_to_edit': user,
        'profile': profile,
        'departments': Department.objects.all(),
        'user_types': allowed_user_types
    }
    return render(request, 'feedback/edit_user.html', context)

@login_required
def delete_user(request, user_id):
    # Only admin can delete users
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        user = User.objects.get(id=user_id)
    except User.DoesNotExist:
        messages.error(request, 'User not found.')
        return redirect('feedback:manage_users')

    # Prevent deleting superuser accounts or self
    if user.is_superuser:
        messages.error(request, 'Cannot delete superuser accounts.')
        return redirect('feedback:manage_users')

    if user.id == request.user.id:
        messages.error(request, 'Cannot delete your own account.')
        return redirect('feedback:manage_users')

    if request.method == 'POST':
        username = user.username
        user.delete()
        messages.success(request, f'User "{username}" deleted successfully!')
        return redirect('feedback:manage_users')

    context = {
        'user_to_delete': user,
    }
    return render(request, 'feedback/delete_user_confirm.html', context)

# Question Management Views
@login_required
def survey_questions(request, survey_id):
    # Only admin can manage questions
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        survey = Survey.objects.get(id=survey_id)
    except Survey.DoesNotExist:
        messages.error(request, 'Survey not found.')
        return redirect('feedback:view_all_surveys')

    questions = Question.objects.filter(survey=survey).order_by('order')

    context = {
        'survey': survey,
        'questions': questions,
        'question_count': questions.count(),
        'question_types': Question.QUESTION_TYPES,
    }
    return render(request, 'feedback/survey_questions.html', context)

@login_required
def add_question(request, survey_id):
    # Only admin can add questions
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        survey = Survey.objects.get(id=survey_id)
    except Survey.DoesNotExist:
        messages.error(request, 'Survey not found.')
        return redirect('feedback:view_all_surveys')

    if request.method == 'POST':
        text = request.POST.get('text')
        question_type = request.POST.get('question_type')
        is_required = request.POST.get('is_required') == 'on'

        if text and question_type:
            # Get the next order number
            last_question = Question.objects.filter(survey=survey).order_by('-order').first()
            next_order = (last_question.order + 1) if last_question else 1

            question = Question.objects.create(
                survey=survey,
                text=text,
                question_type=question_type,
                is_required=is_required,
                order=next_order
            )

            # Handle multiple choice options
            if question_type == 'multiple_choice':
                choices = request.POST.getlist('choices[]')
                for i, choice_text in enumerate(choices):
                    if choice_text.strip():
                        QuestionChoice.objects.create(
                            question=question,
                            text=choice_text.strip(),
                            value=choice_text.strip(),
                            order=i + 1
                        )

            messages.success(request, f'Question added successfully!')
            return redirect('feedback:survey_questions', survey_id=survey.id)
        else:
            messages.error(request, 'Please fill in all required fields.')

    context = {
        'survey': survey,
        'question_types': Question.QUESTION_TYPES,
    }
    return render(request, 'feedback/add_question.html', context)

@login_required
def edit_question(request, question_id):
    # Only admin can edit questions
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        question = Question.objects.get(id=question_id)
    except Question.DoesNotExist:
        messages.error(request, 'Question not found.')
        return redirect('feedback:view_all_surveys')

    if request.method == 'POST':
        text = request.POST.get('text')
        question_type = request.POST.get('question_type')
        is_required = request.POST.get('is_required') == 'on'

        if text and question_type:
            question.text = text
            question.question_type = question_type
            question.is_required = is_required
            question.save()

            # Handle multiple choice options
            if question_type == 'multiple_choice':
                # Delete existing choices
                question.choices.all().delete()

                # Add new choices
                choices = request.POST.getlist('choices[]')
                for i, choice_text in enumerate(choices):
                    if choice_text.strip():
                        QuestionChoice.objects.create(
                            question=question,
                            text=choice_text.strip(),
                            value=choice_text.strip(),
                            order=i + 1
                        )

            messages.success(request, 'Question updated successfully!')
            return redirect('feedback:survey_questions', survey_id=question.survey.id)
        else:
            messages.error(request, 'Please fill in all required fields.')

    context = {
        'question': question,
        'survey': question.survey,
        'question_types': Question.QUESTION_TYPES,
        'existing_choices': question.choices.all().order_by('order') if question.question_type == 'multiple_choice' else None,
    }
    return render(request, 'feedback/edit_question.html', context)

@login_required
def delete_question(request, question_id):
    # Only admin can delete questions
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        question = Question.objects.get(id=question_id)
        survey_id = question.survey.id
        question.delete()
        messages.success(request, 'Question deleted successfully!')
    except Question.DoesNotExist:
        messages.error(request, 'Question not found.')
        return redirect('feedback:view_all_surveys')

    return redirect('feedback:survey_questions', survey_id=survey_id)

@login_required
def preview_survey(request, survey_id):
    # Only admin can preview surveys
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        survey = Survey.objects.get(id=survey_id)
    except Survey.DoesNotExist:
        messages.error(request, 'Survey not found.')
        return redirect('feedback:view_all_surveys')

    questions = Question.objects.filter(survey=survey).order_by('order')

    context = {
        'survey': survey,
        'questions': questions,
        'is_preview': True,
    }
    return render(request, 'feedback/preview_survey.html', context)

# Student Survey Interface Views
@login_required
def student_surveys(request):
    # Only students can access this view
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        if user_profile.user_type != 'student':
            messages.error(request, 'Access denied. Student account required.')
            return redirect('feedback:home')
    except UserProfile.DoesNotExist:
        messages.error(request, 'User profile not found. Please contact administrator.')
        return redirect('feedback:home')

    # Get active surveys for student's department
    available_surveys = Survey.objects.filter(
        is_active=True,
        start_date__lte=timezone.now(),
        end_date__gte=timezone.now(),
        department=user_profile.department
    ).order_by('-created_at')

    # Get completed surveys by this student
    student_hash_prefix = FeedbackSubmission.create_student_hash(request.user.id, 0)[:32]  # Use first 32 chars as prefix
    completed_survey_ids = FeedbackSubmission.objects.filter(
        student_hash__startswith=student_hash_prefix
    ).values_list('survey_id', flat=True)

    # Separate available and completed surveys
    pending_surveys = available_surveys.exclude(id__in=completed_survey_ids)
    completed_surveys = available_surveys.filter(id__in=completed_survey_ids)

    context = {
        'user_profile': user_profile,
        'pending_surveys': pending_surveys,
        'completed_surveys': completed_surveys,
        'pending_count': pending_surveys.count(),
        'completed_count': completed_surveys.count(),
    }
    return render(request, 'feedback/student_surveys.html', context)

@login_required
def take_survey(request, survey_id):
    # Only students can take surveys
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        if user_profile.user_type != 'student':
            messages.error(request, 'Access denied. Student account required.')
            return redirect('feedback:home')
    except UserProfile.DoesNotExist:
        messages.error(request, 'User profile not found. Please contact administrator.')
        return redirect('feedback:home')

    # Get the survey
    try:
        survey = Survey.objects.get(id=survey_id)
    except Survey.DoesNotExist:
        messages.error(request, 'Survey not found.')
        return redirect('feedback:student_surveys')

    # Check if survey is active and accessible
    if not survey.is_active:
        messages.error(request, 'This survey is not currently active.')
        return redirect('feedback:student_surveys')

    if survey.start_date > timezone.now():
        messages.error(request, 'This survey has not started yet.')
        return redirect('feedback:student_surveys')

    if survey.end_date < timezone.now():
        messages.error(request, 'This survey has ended.')
        return redirect('feedback:student_surveys')

    # Check if student's department matches survey department
    if survey.department != user_profile.department:
        messages.error(request, 'This survey is not available for your department.')
        return redirect('feedback:student_surveys')

    # Check if student has already completed this survey
    student_hash = FeedbackSubmission.create_student_hash(request.user.id, survey.id)
    if FeedbackSubmission.objects.filter(student_hash=student_hash, survey=survey).exists():
        messages.warning(request, 'You have already completed this survey.')
        return redirect('feedback:student_surveys')

    # Get survey questions
    questions = Question.objects.filter(survey=survey).order_by('order')

    if not questions.exists():
        messages.error(request, 'This survey has no questions yet.')
        return redirect('feedback:student_surveys')

    context = {
        'survey': survey,
        'questions': questions,
        'user_profile': user_profile,
    }
    return render(request, 'feedback/take_survey.html', context)

@login_required
def submit_survey(request, survey_id):
    # Only students can submit surveys
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        if user_profile.user_type != 'student':
            messages.error(request, 'Access denied. Student account required.')
            return redirect('feedback:home')
    except UserProfile.DoesNotExist:
        messages.error(request, 'User profile not found. Please contact administrator.')
        return redirect('feedback:home')

    if request.method != 'POST':
        return redirect('feedback:take_survey', survey_id=survey_id)

    # Get the survey
    try:
        survey = Survey.objects.get(id=survey_id)
    except Survey.DoesNotExist:
        messages.error(request, 'Survey not found.')
        return redirect('feedback:student_surveys')

    # Verify survey is still accessible
    if not survey.is_active or survey.end_date < timezone.now():
        messages.error(request, 'This survey is no longer available.')
        return redirect('feedback:student_surveys')

    # Check if student has already completed this survey
    student_hash = FeedbackSubmission.create_student_hash(request.user.id, survey.id)
    if FeedbackSubmission.objects.filter(student_hash=student_hash, survey=survey).exists():
        messages.warning(request, 'You have already completed this survey.')
        return redirect('feedback:student_surveys')

    # Get survey questions
    questions = Question.objects.filter(survey=survey).order_by('order')

    # Validate responses
    errors = []
    responses = {}

    for question in questions:
        field_name = f'question_{question.id}'
        response_value = request.POST.get(field_name, '').strip()

        # Check required questions
        if question.is_required and not response_value:
            errors.append(f'Question {question.order} is required.')
            continue

        # Validate based on question type
        if response_value:
            if question.question_type == 'rating':
                try:
                    rating = int(response_value)
                    if rating < 1 or rating > 5:
                        errors.append(f'Question {question.order}: Rating must be between 1 and 5.')
                    else:
                        responses[question.id] = str(rating)
                except ValueError:
                    errors.append(f'Question {question.order}: Invalid rating value.')

            elif question.question_type == 'yes_no':
                if response_value not in ['yes', 'no']:
                    errors.append(f'Question {question.order}: Please select Yes or No.')
                else:
                    responses[question.id] = response_value

            elif question.question_type == 'multiple_choice':
                # Validate that the choice exists
                valid_choice = QuestionChoice.objects.filter(question=question, value=response_value).first()
                if not valid_choice:
                    # Debug: show available choices
                    available_choices = QuestionChoice.objects.filter(question=question)
                    choice_values = [c.value for c in available_choices]
                    errors.append(f'Question {question.order}: Invalid choice "{response_value}". Available: {choice_values}')
                else:
                    responses[question.id] = response_value

            elif question.question_type == 'text':
                if len(response_value) > 1000:  # Reasonable limit
                    errors.append(f'Question {question.order}: Response too long (max 1000 characters).')
                else:
                    responses[question.id] = response_value

    # If there are errors, return to form
    if errors:
        messages.error(request, f'Please fix the following issues:')
        for error in errors:
            messages.error(request, error)
        return redirect('feedback:take_survey', survey_id=survey_id)

    # Debug: Check if we have any responses
    if not responses:
        messages.error(request, 'No responses received. Please fill out the survey and try again.')
        return redirect('feedback:take_survey', survey_id=survey_id)

    # Create feedback submission
    try:
        # Get client IP
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip_address = x_forwarded_for.split(',')[0]
        else:
            ip_address = request.META.get('REMOTE_ADDR')

        # Create submission record
        submission = FeedbackSubmission.objects.create(
            survey=survey,
            student_hash=student_hash,
            ip_address=ip_address
        )

        # Store individual responses using existing model structure
        from .models import FeedbackResponse
        for question_id, response_value in responses.items():
            question = Question.objects.get(id=question_id)

            # Store response based on question type
            response_data = {'submission': submission, 'question': question}

            if question.question_type == 'rating':
                response_data['rating_value'] = int(response_value)
            elif question.question_type == 'text':
                response_data['text_value'] = response_value
            elif question.question_type in ['multiple_choice', 'yes_no']:
                response_data['choice_value'] = response_value

            FeedbackResponse.objects.create(**response_data)

        messages.success(request, 'Thank you! Your feedback has been submitted successfully.')
        return redirect('feedback:student_surveys')

    except Exception as e:
        # More detailed error message for debugging
        error_msg = f'An error occurred while submitting your feedback: {str(e)}'
        messages.error(request, error_msg)
        print(f"Survey submission error: {e}")  # For server logs
        import traceback
        traceback.print_exc()  # For server logs
        return redirect('feedback:take_survey', survey_id=survey_id)

# Lecturer Dashboard and Analytics Views
@login_required
def lecturer_dashboard(request):
    # Only lecturers can access this view
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        if user_profile.user_type != 'lecturer':
            # Redirect non-lecturers to appropriate dashboard
            if user_profile.user_type == 'admin' or request.user.is_staff:
                return redirect('feedback:admin_dashboard')
            elif user_profile.user_type == 'student':
                return redirect('feedback:student_dashboard')
            else:
                messages.error(request, 'Access denied.')
                return redirect('feedback:home')
    except UserProfile.DoesNotExist:
        messages.error(request, 'User profile not found. Please contact administrator.')
        return redirect('feedback:home')

    # Get surveys for this lecturer's department (simplified approach)
    # For now, lecturers see all surveys in their department
    lecturer_surveys = Survey.objects.filter(
        department=user_profile.department
    ).order_by('-created_at')

    # Get basic statistics
    total_surveys = lecturer_surveys.count()
    active_surveys = lecturer_surveys.filter(is_active=True).count()
    completed_surveys = lecturer_surveys.filter(is_active=False, end_date__lt=timezone.now()).count()

    # Get surveys with feedback
    surveys_with_feedback = []
    for survey in lecturer_surveys:
        feedback_count = FeedbackSubmission.objects.filter(survey=survey).count()
        if feedback_count > 0:
            surveys_with_feedback.append({
                'survey': survey,
                'feedback_count': feedback_count
            })

    context = {
        'user_profile': user_profile,
        'lecturer_surveys': lecturer_surveys[:5],  # Show latest 5
        'surveys_with_feedback': surveys_with_feedback[:5],  # Show latest 5 with feedback
        'total_surveys': total_surveys,
        'active_surveys': active_surveys,
        'completed_surveys': completed_surveys,
        'feedback_available': len(surveys_with_feedback),
    }
    return render(request, 'feedback/lecturer_dashboard.html', context)

@login_required
def lecturer_survey_results(request, survey_id):
    # Only lecturers can access this view
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        if user_profile.user_type != 'lecturer':
            messages.error(request, 'Access denied. Lecturer account required.')
            return redirect('feedback:home')
    except UserProfile.DoesNotExist:
        messages.error(request, 'User profile not found. Please contact administrator.')
        return redirect('feedback:home')

    # Get the survey and verify lecturer has access
    try:
        survey = Survey.objects.get(id=survey_id)
    except Survey.DoesNotExist:
        messages.error(request, 'Survey not found.')
        return redirect('feedback:lecturer_dashboard')

    # Check if lecturer has access to this survey (same department)
    if survey.department != user_profile.department:
        messages.error(request, 'Access denied. You can only view surveys from your department.')
        return redirect('feedback:lecturer_dashboard')

    # Get survey questions and responses
    questions = Question.objects.filter(survey=survey).order_by('order')
    submissions = FeedbackSubmission.objects.filter(survey=survey)

    if not submissions.exists():
        messages.info(request, 'No feedback has been submitted for this survey yet.')
        return redirect('feedback:lecturer_dashboard')

    # Process responses for each question
    question_results = []
    for question in questions:
        responses = FeedbackResponse.objects.filter(
            submission__survey=survey,
            question=question
        )

        result = {
            'question': question,
            'total_responses': responses.count(),
            'responses': responses
        }

        if question.question_type == 'rating':
            # Calculate rating statistics
            ratings = [r.rating_value for r in responses if r.rating_value]
            if ratings:
                result['average_rating'] = sum(ratings) / len(ratings)
                result['rating_distribution'] = {
                    '1': ratings.count(1),
                    '2': ratings.count(2),
                    '3': ratings.count(3),
                    '4': ratings.count(4),
                    '5': ratings.count(5),
                }

        elif question.question_type == 'yes_no':
            # Count yes/no responses
            yes_count = responses.filter(choice_value='yes').count()
            no_count = responses.filter(choice_value='no').count()
            total = yes_count + no_count
            result['yes_percentage'] = (yes_count / total * 100) if total > 0 else 0
            result['no_percentage'] = (no_count / total * 100) if total > 0 else 0
            result['yes_count'] = yes_count
            result['no_count'] = no_count

        elif question.question_type == 'multiple_choice':
            # Count choice responses
            choice_counts = {}
            for choice in QuestionChoice.objects.filter(question=question):
                count = responses.filter(choice_value=choice.value).count()
                choice_counts[choice.text] = count
            result['choice_counts'] = choice_counts

        elif question.question_type == 'text':
            # Get all text responses
            text_responses = [r.text_value for r in responses if r.text_value and r.text_value.strip()]
            result['text_responses'] = text_responses

        question_results.append(result)

    context = {
        'survey': survey,
        'user_profile': user_profile,
        'question_results': question_results,
        'total_submissions': submissions.count(),
        'questions_count': questions.count(),
    }
    return render(request, 'feedback/lecturer_survey_results.html', context)

# Admin Analytics Views
@login_required
def admin_survey_results(request, survey_id):
    # Only admin can access this view
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    # Get the survey
    try:
        survey = Survey.objects.get(id=survey_id)
    except Survey.DoesNotExist:
        messages.error(request, 'Survey not found.')
        return redirect('feedback:view_all_surveys')

    # Get survey questions and responses (same logic as lecturer view but with admin access)
    questions = Question.objects.filter(survey=survey).order_by('order')
    submissions = FeedbackSubmission.objects.filter(survey=survey)

    if not submissions.exists():
        messages.info(request, 'No feedback has been submitted for this survey yet.')
        return redirect('feedback:view_all_surveys')

    # Process responses for each question (same logic as lecturer view)
    question_results = []
    for question in questions:
        responses = FeedbackResponse.objects.filter(
            submission__survey=survey,
            question=question
        )

        result = {
            'question': question,
            'total_responses': responses.count(),
            'responses': responses
        }

        if question.question_type == 'rating':
            # Calculate rating statistics
            ratings = [r.rating_value for r in responses if r.rating_value]
            if ratings:
                result['average_rating'] = sum(ratings) / len(ratings)
                result['rating_distribution'] = {
                    '1': ratings.count(1),
                    '2': ratings.count(2),
                    '3': ratings.count(3),
                    '4': ratings.count(4),
                    '5': ratings.count(5),
                }

        elif question.question_type == 'yes_no':
            # Count yes/no responses
            yes_count = responses.filter(choice_value='yes').count()
            no_count = responses.filter(choice_value='no').count()
            total = yes_count + no_count
            result['yes_percentage'] = (yes_count / total * 100) if total > 0 else 0
            result['no_percentage'] = (no_count / total * 100) if total > 0 else 0
            result['yes_count'] = yes_count
            result['no_count'] = no_count

        elif question.question_type == 'multiple_choice':
            # Count choice responses
            choice_counts = {}
            for choice in QuestionChoice.objects.filter(question=question):
                count = responses.filter(choice_value=choice.value).count()
                choice_counts[choice.text] = count
            result['choice_counts'] = choice_counts

        elif question.question_type == 'text':
            # Get all text responses
            text_responses = [r.text_value for r in responses if r.text_value and r.text_value.strip()]
            result['text_responses'] = text_responses

        question_results.append(result)

    # Additional admin-only statistics
    department_stats = {
        'total_students': UserProfile.objects.filter(
            user_type='student',
            department=survey.department
        ).count(),
        'response_rate': (submissions.count() / UserProfile.objects.filter(
            user_type='student',
            department=survey.department
        ).count() * 100) if UserProfile.objects.filter(
            user_type='student',
            department=survey.department
        ).count() > 0 else 0
    }

    context = {
        'survey': survey,
        'question_results': question_results,
        'total_submissions': submissions.count(),
        'questions_count': questions.count(),
        'department_stats': department_stats,
        'is_admin_view': True,
    }
    return render(request, 'feedback/admin_survey_results.html', context)

# Export functionality
@login_required
def export_survey_csv(request, survey_id):
    # Only admin can export
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        survey = Survey.objects.get(id=survey_id)
    except Survey.DoesNotExist:
        messages.error(request, 'Survey not found.')
        return redirect('feedback:view_all_surveys')

    import csv
    from django.http import HttpResponse

    # Create CSV response
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="survey_{survey_id}_results.csv"'

    writer = csv.writer(response)

    # Write header
    writer.writerow(['Survey Title', survey.title])
    writer.writerow(['Department', survey.department.name if survey.department else 'N/A'])
    writer.writerow(['Created', survey.created_at.strftime('%Y-%m-%d %H:%M')])
    writer.writerow(['Total Submissions', FeedbackSubmission.objects.filter(survey=survey).count()])
    writer.writerow([])  # Empty row

    # Get questions and responses
    questions = Question.objects.filter(survey=survey).order_by('order')

    for question in questions:
        writer.writerow([f'Question {question.order}', question.text])
        writer.writerow(['Type', question.get_question_type_display()])
        writer.writerow(['Required', 'Yes' if question.is_required else 'No'])

        responses = FeedbackResponse.objects.filter(
            submission__survey=survey,
            question=question
        )

        if question.question_type == 'rating':
            ratings = [r.rating_value for r in responses if r.rating_value]
            if ratings:
                writer.writerow(['Average Rating', sum(ratings) / len(ratings)])
                writer.writerow(['Total Responses', len(ratings)])
                for i in range(1, 6):
                    count = ratings.count(i)
                    writer.writerow([f'{i} Star', count])

        elif question.question_type == 'yes_no':
            yes_count = responses.filter(choice_value='yes').count()
            no_count = responses.filter(choice_value='no').count()
            total = yes_count + no_count
            writer.writerow(['Yes', f'{yes_count} ({yes_count/total*100:.1f}%)' if total > 0 else '0'])
            writer.writerow(['No', f'{no_count} ({no_count/total*100:.1f}%)' if total > 0 else '0'])

        elif question.question_type == 'multiple_choice':
            choices = QuestionChoice.objects.filter(question=question)
            for choice in choices:
                count = responses.filter(choice_value=choice.value).count()
                writer.writerow([choice.text, count])

        elif question.question_type == 'text':
            text_responses = [r.text_value for r in responses if r.text_value and r.text_value.strip()]
            writer.writerow(['Text Responses', len(text_responses)])
            for i, text in enumerate(text_responses, 1):
                writer.writerow([f'Response {i}', text])

        writer.writerow([])  # Empty row between questions

    return response

@login_required
def export_survey_pdf(request, survey_id):
    # Only admin can export
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        survey = Survey.objects.get(id=survey_id)
    except Survey.DoesNotExist:
        messages.error(request, 'Survey not found.')
        return redirect('feedback:view_all_surveys')

    from django.http import HttpResponse
    from django.template.loader import get_template

    # For now, return a simple text-based PDF alternative
    # In a production system, you would use libraries like ReportLab or WeasyPrint

    response = HttpResponse(content_type='text/plain')
    response['Content-Disposition'] = f'attachment; filename="survey_{survey_id}_report.txt"'

    # Generate simple text report
    report_lines = []
    report_lines.append(f"SURVEY RESULTS REPORT")
    report_lines.append(f"=" * 50)
    report_lines.append(f"Survey: {survey.title}")
    report_lines.append(f"Department: {survey.department.name if survey.department else 'N/A'}")
    report_lines.append(f"Created: {survey.created_at.strftime('%Y-%m-%d %H:%M')}")
    report_lines.append(f"Total Submissions: {FeedbackSubmission.objects.filter(survey=survey).count()}")
    report_lines.append("")

    # Get questions and responses
    questions = Question.objects.filter(survey=survey).order_by('order')

    for question in questions:
        report_lines.append(f"Question {question.order}: {question.text}")
        report_lines.append(f"Type: {question.get_question_type_display()}")
        report_lines.append(f"Required: {'Yes' if question.is_required else 'No'}")
        report_lines.append("-" * 30)

        responses = FeedbackResponse.objects.filter(
            submission__survey=survey,
            question=question
        )

        if question.question_type == 'rating':
            ratings = [r.rating_value for r in responses if r.rating_value]
            if ratings:
                avg_rating = sum(ratings) / len(ratings)
                report_lines.append(f"Average Rating: {avg_rating:.1f}/5.0")
                report_lines.append(f"Total Responses: {len(ratings)}")
                for i in range(1, 6):
                    count = ratings.count(i)
                    percentage = (count / len(ratings) * 100) if len(ratings) > 0 else 0
                    report_lines.append(f"{i} Star: {count} ({percentage:.1f}%)")

        elif question.question_type == 'yes_no':
            yes_count = responses.filter(choice_value='yes').count()
            no_count = responses.filter(choice_value='no').count()
            total = yes_count + no_count
            if total > 0:
                report_lines.append(f"Yes: {yes_count} ({yes_count/total*100:.1f}%)")
                report_lines.append(f"No: {no_count} ({no_count/total*100:.1f}%)")

        elif question.question_type == 'multiple_choice':
            choices = QuestionChoice.objects.filter(question=question)
            total_responses = responses.count()
            for choice in choices:
                count = responses.filter(choice_value=choice.value).count()
                percentage = (count / total_responses * 100) if total_responses > 0 else 0
                report_lines.append(f"{choice.text}: {count} ({percentage:.1f}%)")

        elif question.question_type == 'text':
            text_responses = [r.text_value for r in responses if r.text_value and r.text_value.strip()]
            report_lines.append(f"Text Responses ({len(text_responses)}):")
            for i, text in enumerate(text_responses[:10], 1):  # Limit to first 10 for readability
                report_lines.append(f"{i}. {text}")
            if len(text_responses) > 10:
                report_lines.append(f"... and {len(text_responses) - 10} more responses")

        report_lines.append("")
        report_lines.append("")

    response.write('\n'.join(report_lines))
    return response

# Simple trend analysis
@login_required
def department_analytics(request):
    # Only admin can access this view
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    # Get department analytics with trend data
    departments = Department.objects.all()
    department_analytics = []

    for dept in departments:
        # Get surveys for this department
        dept_surveys = Survey.objects.filter(department=dept).order_by('-created_at')

        # Calculate basic statistics
        total_surveys = dept_surveys.count()
        active_surveys = dept_surveys.filter(is_active=True).count()
        completed_surveys = dept_surveys.filter(is_active=False).count()

        # Get students and lecturers
        dept_students = UserProfile.objects.filter(user_type='student', department=dept).count()
        dept_lecturers = UserProfile.objects.filter(user_type='lecturer', department=dept).count()

        # Calculate feedback statistics
        total_submissions = FeedbackSubmission.objects.filter(survey__department=dept).count()

        # Calculate response rate
        response_rate = 0
        if dept_students > 0 and total_surveys > 0:
            expected_responses = dept_students * total_surveys
            response_rate = (total_submissions / expected_responses * 100) if expected_responses > 0 else 0

        # Get recent activity (last 30 days)
        from datetime import timedelta
        recent_submissions = FeedbackSubmission.objects.filter(
            survey__department=dept,
            submitted_at__gte=timezone.now() - timedelta(days=30)
        ).count()

        # Simple trend: compare last 30 days vs previous 30 days
        previous_submissions = FeedbackSubmission.objects.filter(
            survey__department=dept,
            submitted_at__gte=timezone.now() - timedelta(days=60),
            submitted_at__lt=timezone.now() - timedelta(days=30)
        ).count()

        trend = "stable"
        if recent_submissions > previous_submissions:
            trend = "increasing"
        elif recent_submissions < previous_submissions:
            trend = "decreasing"

        # Get top performing surveys (by response count)
        top_surveys = []
        for survey in dept_surveys[:5]:  # Top 5 recent surveys
            feedback_count = FeedbackSubmission.objects.filter(survey=survey).count()
            if feedback_count > 0:
                top_surveys.append({
                    'survey': survey,
                    'feedback_count': feedback_count
                })

        department_analytics.append({
            'department': dept,
            'total_surveys': total_surveys,
            'active_surveys': active_surveys,
            'completed_surveys': completed_surveys,
            'students': dept_students,
            'lecturers': dept_lecturers,
            'total_submissions': total_submissions,
            'response_rate': response_rate,
            'recent_submissions': recent_submissions,
            'previous_submissions': previous_submissions,
            'trend': trend,
            'top_surveys': top_surveys
        })

    # Overall system trends
    total_system_submissions = FeedbackSubmission.objects.count()
    recent_system_submissions = FeedbackSubmission.objects.filter(
        submitted_at__gte=timezone.now() - timedelta(days=30)
    ).count()

    context = {
        'department_analytics': department_analytics,
        'total_system_submissions': total_system_submissions,
        'recent_system_submissions': recent_system_submissions,
    }
    return render(request, 'feedback/department_analytics.html', context)

# Department Management Views
@login_required
def manage_departments(request):
    # Only admin can manage departments
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    departments = Department.objects.all().order_by('code')

    # Get usage statistics for each department
    department_stats = []
    for dept in departments:
        users_count = UserProfile.objects.filter(department=dept).count()
        surveys_count = Survey.objects.filter(department=dept).count()
        can_delete = users_count == 0 and surveys_count == 0

        department_stats.append({
            'department': dept,
            'users_count': users_count,
            'surveys_count': surveys_count,
            'can_delete': can_delete
        })

    context = {
        'department_stats': department_stats,
    }
    return render(request, 'feedback/manage_departments.html', context)

@login_required
def add_department(request):
    # Only admin can add departments
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    if request.method == 'POST':
        name = request.POST.get('name')
        code = request.POST.get('code')
        description = request.POST.get('description', '')

        if name and code:
            # Check if code already exists
            if Department.objects.filter(code=code.upper()).exists():
                messages.error(request, f'Department code "{code.upper()}" already exists.')
            else:
                try:
                    department = Department.objects.create(
                        name=name.strip(),
                        code=code.upper().strip(),
                        description=description.strip()
                    )
                    messages.success(request, f'Department "{department.name}" created successfully!')
                    return redirect('feedback:manage_departments')
                except Exception as e:
                    messages.error(request, f'Error creating department: {str(e)}')
        else:
            messages.error(request, 'Please fill in all required fields.')

    context = {}
    return render(request, 'feedback/add_department.html', context)

@login_required
def edit_department(request, department_id):
    # Only admin can edit departments
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        department = Department.objects.get(id=department_id)
    except Department.DoesNotExist:
        messages.error(request, 'Department not found.')
        return redirect('feedback:manage_departments')

    if request.method == 'POST':
        name = request.POST.get('name')
        code = request.POST.get('code')
        description = request.POST.get('description', '')

        if name and code:
            # Check if code already exists (excluding current department)
            if Department.objects.filter(code=code.upper()).exclude(id=department_id).exists():
                messages.error(request, f'Department code "{code.upper()}" already exists.')
            else:
                try:
                    department.name = name.strip()
                    department.code = code.upper().strip()
                    department.description = description.strip()
                    department.save()
                    messages.success(request, f'Department "{department.name}" updated successfully!')
                    return redirect('feedback:manage_departments')
                except Exception as e:
                    messages.error(request, f'Error updating department: {str(e)}')
        else:
            messages.error(request, 'Please fill in all required fields.')

    context = {
        'department': department,
    }
    return render(request, 'feedback/edit_department.html', context)

@login_required
def delete_department(request, department_id):
    # Only admin can delete departments
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        department = Department.objects.get(id=department_id)
    except Department.DoesNotExist:
        messages.error(request, 'Department not found.')
        return redirect('feedback:manage_departments')

    # Check if department can be deleted
    users_count = UserProfile.objects.filter(department=department).count()
    surveys_count = Survey.objects.filter(department=department).count()

    if users_count > 0 or surveys_count > 0:
        messages.error(request, f'Cannot delete department "{department.name}". It has {users_count} users and {surveys_count} surveys.')
        return redirect('feedback:manage_departments')

    if request.method == 'POST':
        department_name = department.name
        department.delete()
        messages.success(request, f'Department "{department_name}" deleted successfully!')
        return redirect('feedback:manage_departments')

    context = {
        'department': department,
        'users_count': users_count,
        'surveys_count': surveys_count,
    }
    return render(request, 'feedback/delete_department_confirm.html', context)

# Course Management Views
@login_required
def manage_courses(request):
    # Only admin can manage courses
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    courses = Course.objects.all().select_related('department').order_by('department__code', 'code')

    # Get usage statistics for each course
    course_stats = []
    for course in courses:
        assignments_count = CourseAssignment.objects.filter(course=course).count()
        can_delete = assignments_count == 0

        course_stats.append({
            'course': course,
            'assignments_count': assignments_count,
            'can_delete': can_delete
        })

    context = {
        'course_stats': course_stats,
    }
    return render(request, 'feedback/manage_courses.html', context)

@login_required
def add_course(request):
    # Only admin can add courses
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    if request.method == 'POST':
        name = request.POST.get('name')
        code = request.POST.get('code')
        department_id = request.POST.get('department')
        description = request.POST.get('description', '')

        if name and code and department_id:
            try:
                department = Department.objects.get(id=department_id)

                # Check if code already exists in the same department
                if Course.objects.filter(code=code.upper(), department=department).exists():
                    messages.error(request, f'Course code "{code.upper()}" already exists in {department.name}.')
                else:
                    course = Course.objects.create(
                        name=name.strip(),
                        code=code.upper().strip(),
                        department=department,
                        description=description.strip()
                    )
                    messages.success(request, f'Course "{course.name}" created successfully!')
                    return redirect('feedback:manage_courses')
            except Department.DoesNotExist:
                messages.error(request, 'Selected department not found.')
            except Exception as e:
                messages.error(request, f'Error creating course: {str(e)}')
        else:
            messages.error(request, 'Please fill in all required fields.')

    departments = Department.objects.all().order_by('code')
    context = {
        'departments': departments,
    }
    return render(request, 'feedback/add_course.html', context)

@login_required
def edit_course(request, course_id):
    # Only admin can edit courses
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        course = Course.objects.get(id=course_id)
    except Course.DoesNotExist:
        messages.error(request, 'Course not found.')
        return redirect('feedback:manage_courses')

    if request.method == 'POST':
        name = request.POST.get('name')
        code = request.POST.get('code')
        department_id = request.POST.get('department')
        description = request.POST.get('description', '')

        if name and code and department_id:
            try:
                department = Department.objects.get(id=department_id)

                # Check if code already exists in the same department (excluding current course)
                if Course.objects.filter(code=code.upper(), department=department).exclude(id=course_id).exists():
                    messages.error(request, f'Course code "{code.upper()}" already exists in {department.name}.')
                else:
                    course.name = name.strip()
                    course.code = code.upper().strip()
                    course.department = department
                    course.description = description.strip()
                    course.save()
                    messages.success(request, f'Course "{course.name}" updated successfully!')
                    return redirect('feedback:manage_courses')
            except Department.DoesNotExist:
                messages.error(request, 'Selected department not found.')
            except Exception as e:
                messages.error(request, f'Error updating course: {str(e)}')
        else:
            messages.error(request, 'Please fill in all required fields.')

    departments = Department.objects.all().order_by('code')
    context = {
        'course': course,
        'departments': departments,
    }
    return render(request, 'feedback/edit_course.html', context)

@login_required
def delete_course(request, course_id):
    # Only admin can delete courses
    if not (request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    try:
        course = Course.objects.get(id=course_id)
    except Course.DoesNotExist:
        messages.error(request, 'Course not found.')
        return redirect('feedback:manage_courses')

    # Check if course can be deleted
    assignments_count = CourseAssignment.objects.filter(course=course).count()

    if assignments_count > 0:
        messages.error(request, f'Cannot delete course "{course.name}". It has {assignments_count} assignments.')
        return redirect('feedback:manage_courses')

    if request.method == 'POST':
        course_name = course.name
        course.delete()
        messages.success(request, f'Course "{course_name}" deleted successfully!')
        return redirect('feedback:manage_courses')

    context = {
        'course': course,
        'assignments_count': assignments_count,
    }
    return render(request, 'feedback/delete_course_confirm.html', context)
