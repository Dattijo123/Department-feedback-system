from django.urls import path
from . import simple_views

app_name = 'feedback'

urlpatterns = [
    path('', simple_views.home, name='home'),
    path('login/', simple_views.simple_login, name='simple_login'),
    path('logout/', simple_views.simple_logout, name='simple_logout'),
    path('dashboard/', simple_views.simple_dashboard, name='simple_dashboard'),
    path('admin-dashboard/', simple_views.admin_dashboard, name='admin_dashboard'),
    path('lecturer-dashboard/', simple_views.lecturer_dashboard, name='lecturer_dashboard'),
    path('student-dashboard/', simple_views.student_dashboard, name='student_dashboard'),
    path('create-survey/', simple_views.create_survey, name='create_survey'),
    path('view-all-surveys/', simple_views.view_all_surveys, name='view_all_surveys'),
    path('add-user/', simple_views.add_user, name='add_user'),
    path('manage-users/', simple_views.manage_users, name='manage_users'),
    path('edit-user/<int:user_id>/', simple_views.edit_user, name='edit_user'),
    path('delete-user/<int:user_id>/', simple_views.delete_user, name='delete_user'),
    # Question Management URLs
    path('survey/<int:survey_id>/questions/', simple_views.survey_questions, name='survey_questions'),
    path('survey/<int:survey_id>/add-question/', simple_views.add_question, name='add_question'),
    path('question/<int:question_id>/edit/', simple_views.edit_question, name='edit_question'),
    path('question/<int:question_id>/delete/', simple_views.delete_question, name='delete_question'),
    path('survey/<int:survey_id>/preview/', simple_views.preview_survey, name='preview_survey'),
    # Student Survey URLs
    path('student-surveys/', simple_views.student_surveys, name='student_surveys'),
    path('survey/<int:survey_id>/take/', simple_views.take_survey, name='take_survey'),
    path('survey/<int:survey_id>/submit/', simple_views.submit_survey, name='submit_survey'),
    # Analytics URLs
    path('lecturer/survey/<int:survey_id>/results/', simple_views.lecturer_survey_results, name='lecturer_survey_results'),
    path('admin-survey/<int:survey_id>/results/', simple_views.admin_survey_results, name='admin_survey_results'),
    # Export URLs
    path('export/survey/<int:survey_id>/csv/', simple_views.export_survey_csv, name='export_survey_csv'),
    path('export/survey/<int:survey_id>/pdf/', simple_views.export_survey_pdf, name='export_survey_pdf'),
    # Analytics URLs
    path('department-analytics/', simple_views.department_analytics, name='department_analytics'),
    # Department Management URLs
    path('manage-departments/', simple_views.manage_departments, name='manage_departments'),
    path('add-department/', simple_views.add_department, name='add_department'),
    path('edit-department/<int:department_id>/', simple_views.edit_department, name='edit_department'),
    path('delete-department/<int:department_id>/', simple_views.delete_department, name='delete_department'),
    # Course Management URLs
    path('manage-courses/', simple_views.manage_courses, name='manage_courses'),
    path('add-course/', simple_views.add_course, name='add_course'),
    path('edit-course/<int:course_id>/', simple_views.edit_course, name='edit_course'),
    path('delete-course/<int:course_id>/', simple_views.delete_course, name='delete_course'),
]
