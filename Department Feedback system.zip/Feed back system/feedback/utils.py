from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from datetime import timedelta
from .models import StudentVerification, AuditLog
from .forms import generate_verification_code
import logging

logger = logging.getLogger(__name__)

def send_verification_email(user):
    """Send verification code to student email"""
    try:
        # Generate verification code
        code = generate_verification_code()
        
        # Create or update verification record
        verification, created = StudentVerification.objects.get_or_create(
            student=user,
            defaults={
                'verification_code': code,
                'expires_at': timezone.now() + timedelta(minutes=15),
                'is_used': False
            }
        )
        
        if not created:
            verification.verification_code = code
            verification.expires_at = timezone.now() + timedelta(minutes=15)
            verification.is_used = False
            verification.save()
        
        # Email content
        subject = 'Department Feedback System - Verification Code'
        message = f"""
        Hello {user.first_name},
        
        Your verification code for the Department Feedback System is: {code}
        
        This code will expire in 15 minutes.
        
        If you did not request this code, please ignore this email.
        
        Best regards,
        Department Feedback System
        """
        
        # Send email (in production, configure proper email backend)
        send_mail(
            subject,
            message,
            settings.DEFAULT_FROM_EMAIL if hasattr(settings, 'DEFAULT_FROM_EMAIL') else 'noreply@university.edu',
            [user.email],
            fail_silently=False,
        )
        
        logger.info(f"Verification email sent to {user.email}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to send verification email to {user.email}: {str(e)}")
        return False

def verify_student_code(user, code):
    """Verify the student's verification code"""
    try:
        verification = StudentVerification.objects.get(
            student=user,
            verification_code=code,
            is_used=False
        )
        
        if verification.is_expired():
            return False, "Verification code has expired"
        
        # Mark as used
        verification.is_used = True
        verification.verified_at = timezone.now()
        verification.save()
        
        # Mark user as verified
        user.is_verified = True
        user.save()
        
        return True, "Verification successful"
        
    except StudentVerification.DoesNotExist:
        return False, "Invalid verification code"

def log_user_action(user, action, details="", ip_address=None):
    """Log user actions for audit trail"""
    try:
        AuditLog.objects.create(
            user=user,
            action=action,
            details=details,
            ip_address=ip_address
        )
    except Exception as e:
        logger.error(f"Failed to log action {action} for user {user}: {str(e)}")

def get_client_ip(request):
    """Get client IP address from request"""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def is_university_email(email):
    """Check if email belongs to university domain"""
    # Add your university domain(s) here
    university_domains = [
        'university.edu',
        'student.university.edu',
        'uni.edu'
    ]
    
    domain = email.split('@')[-1].lower()
    return domain in university_domains
