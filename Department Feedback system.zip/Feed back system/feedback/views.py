from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse, JsonResponse
from django.views.decorators.http import require_http_methods
from django.db.models import Count, Avg
from django.utils import timezone
from .models import CustomUser, Survey, FeedbackSubmission, FeedbackResponse
from .forms import (
    CustomLoginForm, StudentRegistrationForm, StudentVerificationForm,
    FeedbackForm, generate_student_hash
)
from .utils import send_verification_email, verify_student_code, log_user_action, get_client_ip

def home(request):
    context = {
        'active_surveys_count': Survey.objects.filter(is_active=True).count(),
        'total_submissions': FeedbackSubmission.objects.count(),
    }
    return render(request, 'feedback/home.html', context)

def register_view(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.role = 'student'
            user.save()

            # Send verification email
            if send_verification_email(user):
                messages.success(request, 'Registration successful! Please check your email for verification code.')
                return redirect('feedback:verify_email', user_id=user.id)
            else:
                messages.error(request, 'Registration successful but failed to send verification email. Please contact admin.')
                return redirect('feedback:login')
    else:
        form = StudentRegistrationForm()

    return render(request, 'feedback/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = CustomLoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')

            # Try to authenticate with username first, then email
            user = authenticate(request, username=username, password=password)
            if not user:
                try:
                    user_obj = CustomUser.objects.get(email=username)
                    user = authenticate(request, username=user_obj.username, password=password)
                except CustomUser.DoesNotExist:
                    pass

            if user is not None:
                login(request, user)
                log_user_action(user, 'login', ip_address=get_client_ip(request))

                if not user.is_verified and user.role == 'student':
                    messages.info(request, 'Please verify your email before submitting feedback.')
                    return redirect('feedback:verify_email', user_id=user.id)

                return redirect('feedback:home')
            else:
                messages.error(request, 'Invalid credentials')
    else:
        form = CustomLoginForm()

    return render(request, 'feedback/login.html', {'form': form})

def logout_view(request):
    if request.user.is_authenticated:
        log_user_action(request.user, 'logout', ip_address=get_client_ip(request))
    logout(request)
    return redirect('feedback:home')

def verify_email_view(request, user_id):
    user = get_object_or_404(CustomUser, id=user_id)

    if request.method == 'POST':
        form = StudentVerificationForm(request.POST)
        if form.is_valid():
            code = form.cleaned_data['verification_code']
            success, message = verify_student_code(user, code)

            if success:
                messages.success(request, message)
                # Auto-login the user after verification
                login(request, user)
                return redirect('feedback:home')
            else:
                messages.error(request, message)
    else:
        form = StudentVerificationForm()

    context = {
        'form': form,
        'user': user,
        'can_resend': True
    }
    return render(request, 'feedback/verify_email.html', context)

@require_http_methods(["POST"])
def resend_verification(request, user_id):
    user = get_object_or_404(CustomUser, id=user_id)

    if send_verification_email(user):
        messages.success(request, 'Verification code sent successfully!')
    else:
        messages.error(request, 'Failed to send verification code. Please try again.')

    return redirect('feedback:verify_email', user_id=user.id)

@login_required
def verify_student(request):
    if request.user.is_verified:
        return redirect('feedback:survey_list')

    if request.method == 'POST':
        if send_verification_email(request.user):
            messages.success(request, 'Verification code sent to your email!')
            return redirect('feedback:verify_email', user_id=request.user.id)
        else:
            messages.error(request, 'Failed to send verification code.')

    return render(request, 'feedback/verify.html')

@login_required
def survey_list(request):
    if not request.user.is_verified and request.user.role == 'student':
        messages.warning(request, 'Please verify your email first.')
        return redirect('feedback:verify_student')

    active_surveys = Survey.objects.filter(is_active=True)

    # Filter surveys based on user role
    if request.user.role == 'student':
        # Students can see surveys for their department
        if request.user.department:
            active_surveys = active_surveys.filter(department=request.user.department)

    context = {
        'surveys': active_surveys,
        'user_submissions': FeedbackSubmission.objects.filter(
            student_hash=generate_student_hash(request.user)
        ).values_list('survey_id', flat=True) if request.user.role == 'student' else []
    }
    return render(request, 'feedback/survey_list.html', context)

@login_required
def submit_feedback(request, survey_id):
    survey = get_object_or_404(Survey, id=survey_id, is_active=True)

    if not request.user.is_verified and request.user.role == 'student':
        messages.warning(request, 'Please verify your email first.')
        return redirect('feedback:verify_student')

    # Check if survey is open
    if not survey.is_open():
        messages.error(request, 'This survey is not currently open for submissions.')
        return redirect('feedback:survey_list')

    # Check for duplicate submission
    student_hash = generate_student_hash(request.user)
    if FeedbackSubmission.objects.filter(survey=survey, student_hash=student_hash).exists():
        messages.warning(request, 'You have already submitted feedback for this survey.')
        return redirect('feedback:survey_list')

    if request.method == 'POST':
        form = FeedbackForm(survey, request.POST)
        if form.is_valid():
            # Create submission record
            submission = FeedbackSubmission.objects.create(
                survey=survey,
                student_hash=student_hash,
                ip_address=get_client_ip(request)
            )

            # Save responses
            for question in survey.questions.all():
                field_name = f'question_{question.id}'
                if field_name in form.cleaned_data:
                    response_value = form.cleaned_data[field_name]

                    response = FeedbackResponse(
                        submission=submission,
                        question=question
                    )

                    if question.question_type == 'rating':
                        response.rating_value = int(response_value)
                    elif question.question_type == 'text':
                        response.text_value = response_value
                    else:
                        response.choice_value = response_value

                    response.save()

            # Log the action
            log_user_action(
                request.user,
                'submit_feedback',
                f'Survey: {survey.title}',
                get_client_ip(request)
            )

            messages.success(request, 'Thank you! Your feedback has been submitted successfully.')
            return redirect('feedback:submission_success')
    else:
        form = FeedbackForm(survey)

    context = {
        'survey': survey,
        'form': form
    }
    return render(request, 'feedback/submit_feedback.html', context)

@login_required
def admin_dashboard(request):
    if request.user.role not in ['admin', 'lecturer']:
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    log_user_action(request.user, 'view_dashboard', ip_address=get_client_ip(request))

    # Get filter parameters
    survey_type = request.GET.get('survey_type', '')
    department_id = request.GET.get('department', '')
    date_range = request.GET.get('date_range', '')

    # Base querysets
    surveys_qs = Survey.objects.all()
    submissions_qs = FeedbackSubmission.objects.all()

    # Apply filters
    if survey_type:
        surveys_qs = surveys_qs.filter(survey_type=survey_type)
        submissions_qs = submissions_qs.filter(survey__survey_type=survey_type)

    if department_id:
        surveys_qs = surveys_qs.filter(department_id=department_id)
        submissions_qs = submissions_qs.filter(survey__department_id=department_id)

    if date_range:
        from datetime import datetime, timedelta
        from django.utils import timezone

        days = int(date_range)
        cutoff_date = timezone.now() - timedelta(days=days)
        submissions_qs = submissions_qs.filter(submitted_at__gte=cutoff_date)

    # Calculate statistics
    total_surveys = surveys_qs.count()
    active_surveys = surveys_qs.filter(is_active=True).count()
    total_submissions = submissions_qs.count()

    # Calculate response rate (placeholder calculation)
    response_rate = 0
    if total_surveys > 0:
        response_rate = (total_submissions / (total_surveys * 100)) * 100  # Assuming 100 potential respondents per survey

    # Get departments for filter dropdown
    from .models import Department
    departments = Department.objects.all()

    # Get surveys with submission counts
    surveys_with_counts = []
    for survey in surveys_qs.select_related('department')[:20]:  # Limit to 20 for performance
        submission_count = FeedbackSubmission.objects.filter(survey=survey).count()
        survey.submission_count = submission_count
        surveys_with_counts.append(survey)

    # Recent submissions
    recent_submissions = submissions_qs.select_related('survey__department').order_by('-submitted_at')[:10]

    context = {
        'total_surveys': total_surveys,
        'active_surveys': active_surveys,
        'total_submissions': total_submissions,
        'response_rate': response_rate,
        'departments': departments,
        'surveys': surveys_with_counts,
        'recent_submissions': recent_submissions,
        'avg_response_rate': response_rate,
        'most_active_dept': departments.first().name if departments.exists() else None,
        'peak_time': '2:00 PM - 4:00 PM',  # Placeholder
        # Filter values for form persistence
        'selected_survey_type': survey_type,
        'selected_department': department_id,
        'selected_date_range': date_range,
    }
    return render(request, 'feedback/dashboard.html', context)

@login_required
def submission_success(request):
    return render(request, 'feedback/submission_success.html')

@login_required
def survey_details(request, survey_id):
    if request.user.role not in ['admin', 'lecturer']:
        messages.error(request, 'Access denied. Admin privileges required.')
        return redirect('feedback:home')

    survey = get_object_or_404(Survey, id=survey_id)
    submissions = FeedbackSubmission.objects.filter(survey=survey).select_related()

    # Calculate basic analytics
    total_responses = submissions.count()
    questions_with_stats = []

    for question in survey.questions.all():
        responses = FeedbackResponse.objects.filter(
            submission__survey=survey,
            question=question
        )

        question_stats = {
            'question': question,
            'total_responses': responses.count(),
            'response_data': []
        }

        if question.question_type == 'rating':
            # Calculate rating statistics
            ratings = responses.values_list('rating_value', flat=True)
            if ratings:
                from collections import Counter
                rating_counts = Counter(ratings)
                question_stats['average_rating'] = sum(ratings) / len(ratings)
                question_stats['rating_distribution'] = dict(rating_counts)

        elif question.question_type == 'text':
            # Get text responses (limited for display)
            text_responses = responses.values_list('text_value', flat=True)[:10]
            question_stats['text_responses'] = text_responses

        questions_with_stats.append(question_stats)

    context = {
        'survey': survey,
        'total_responses': total_responses,
        'questions_with_stats': questions_with_stats,
        'submissions': submissions[:20]  # Limit for performance
    }
    return render(request, 'feedback/survey_details.html', context)
