#!/usr/bin/env python
"""
Fix database script - manually create tables and superuser
"""

import os
import sys
import django
from django.core.management import execute_from_command_line

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 50)
    print("Fixing Database for Feedback System")
    print("=" * 50)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        from django.db import connection
        
        print("Step 1: Creating database tables...")
        
        # Create tables manually using SQL
        with connection.cursor() as cursor:
            # Create auth_user table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS auth_user (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    password VARCHAR(128) NOT NULL,
                    last_login DATETIME,
                    is_superuser BOOLEAN NOT NULL,
                    username VARCHAR(150) NOT NULL UNIQUE,
                    first_name VARCHAR(150) NOT NULL,
                    last_name VARCHAR(150) NOT NULL,
                    email VARCHAR(254) NOT NULL,
                    is_staff BOOLEAN NOT NULL,
                    is_active BOOLEAN NOT NULL,
                    date_joined DATETIME NOT NULL
                );
            ''')
            
            # Create other necessary tables
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS auth_group (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name VARCHAR(150) NOT NULL UNIQUE
                );
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS auth_permission (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name VARCHAR(255) NOT NULL,
                    content_type_id INTEGER NOT NULL,
                    codename VARCHAR(100) NOT NULL
                );
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS django_content_type (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    app_label VARCHAR(100) NOT NULL,
                    model VARCHAR(100) NOT NULL
                );
            ''')
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS django_session (
                    session_key VARCHAR(40) PRIMARY KEY,
                    session_data TEXT NOT NULL,
                    expire_date DATETIME NOT NULL
                );
            ''')
            
        print("✓ Database tables created")
        
        print("Step 2: Creating superuser...")
        
        # Create superuser
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser(
                username='admin',
                email='admin@example.com',
                password='admin123'
            )
            print("✓ Superuser created: admin / admin123")
        else:
            print("✓ Superuser already exists")
        
        print("\n" + "=" * 50)
        print("Database Fixed Successfully!")
        print("=" * 50)
        print("You can now:")
        print("1. Run: venv\\Scripts\\python.exe manage.py runserver")
        print("2. Visit: http://localhost:8000")
        print("3. Login with: admin / admin123")
        
    except Exception as e:
        print(f"Error: {e}")
        print("Please check your Django installation and try again.")

if __name__ == "__main__":
    main()
