#!/usr/bin/env python
"""
Fix database schema for Department Feedback System
This script will properly create all the necessary tables
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("Fixing Database Schema for Feedback System")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.db import connection
        from django.contrib.auth.models import User
        from feedback.models import Department, Course, Survey, UserProfile, FeedbackSubmission
        
        print("Step 1: Creating missing tables manually...")
        
        with connection.cursor() as cursor:
            # Create UserProfile table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS feedback_userprofile (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_type VARCHAR(20) NOT NULL DEFAULT 'student',
                    student_id VARCHAR(20) UNIQUE,
                    employee_id VARCHAR(20) UNIQUE,
                    created_at DATETIME NOT NULL,
                    user_id INTEGER NOT NULL UNIQUE REFERENCES auth_user(id),
                    department_id INTEGER REFERENCES feedback_department(id)
                );
            ''')
            
            # Create Department table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS feedback_department (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name VARCHAR(100) NOT NULL UNIQUE,
                    code VARCHAR(10) NOT NULL UNIQUE,
                    description TEXT,
                    created_at DATETIME NOT NULL
                );
            ''')
            
            # Create Course table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS feedback_course (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name VARCHAR(100) NOT NULL,
                    code VARCHAR(20) NOT NULL,
                    semester VARCHAR(10) NOT NULL,
                    year INTEGER NOT NULL,
                    credits INTEGER NOT NULL DEFAULT 3,
                    created_at DATETIME NOT NULL,
                    department_id INTEGER NOT NULL REFERENCES feedback_department(id)
                );
            ''')
            
            # Create Survey table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS feedback_survey (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title VARCHAR(200) NOT NULL,
                    description TEXT NOT NULL,
                    survey_type VARCHAR(20) NOT NULL,
                    is_active BOOLEAN NOT NULL DEFAULT 1,
                    start_date DATETIME NOT NULL,
                    end_date DATETIME NOT NULL,
                    created_at DATETIME NOT NULL,
                    course_id INTEGER REFERENCES feedback_course(id),
                    lecturer_id INTEGER REFERENCES auth_user(id),
                    department_id INTEGER NOT NULL REFERENCES feedback_department(id),
                    created_by_id INTEGER NOT NULL REFERENCES auth_user(id)
                );
            ''')
            
            # Create Question table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS feedback_question (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    text TEXT NOT NULL,
                    question_type VARCHAR(20) NOT NULL,
                    is_required BOOLEAN NOT NULL DEFAULT 1,
                    "order" INTEGER NOT NULL DEFAULT 0,
                    survey_id INTEGER NOT NULL REFERENCES feedback_survey(id)
                );
            ''')
            
            # Create FeedbackSubmission table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS feedback_feedbacksubmission (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_hash VARCHAR(64) NOT NULL,
                    submitted_at DATETIME NOT NULL,
                    ip_address VARCHAR(39),
                    survey_id INTEGER NOT NULL REFERENCES feedback_survey(id)
                );
            ''')
            
        print("✓ Database tables created successfully")
        
        print("Step 2: Creating default department...")
        
        # Create default department
        department, created = Department.objects.get_or_create(
            code='CS',
            defaults={
                'name': 'Computer Science',
                'description': 'Computer Science Department'
            }
        )
        
        if created:
            print("✓ Default Computer Science department created")
        else:
            print("✓ Computer Science department already exists")
        
        print("Step 3: Creating user profiles for existing users...")
        
        # Create UserProfile for existing users
        for user in User.objects.all():
            profile, created = UserProfile.objects.get_or_create(
                user=user,
                defaults={
                    'user_type': 'admin' if user.is_staff else 'student',
                    'department': department
                }
            )
            if created:
                print(f"✓ Created profile for user: {user.username}")
        
        print("\n" + "=" * 60)
        print("Database Schema Fixed Successfully!")
        print("=" * 60)
        print("✓ All tables created")
        print("✓ Default data populated")
        print("✓ User profiles created")
        print("\nYou can now access:")
        print("- Admin Dashboard: http://localhost:8000/admin-dashboard/")
        print("- Student Dashboard: http://localhost:8000/student-dashboard/")
        print("- Create Survey: http://localhost:8000/create-survey/")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        print("Please check your Django installation and try again.")

if __name__ == "__main__":
    main()
