#!/usr/bin/env python
"""
Fix the missing feedback_courseassignment_students table
"""

import os
import sys
import django
import sqlite3

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("FIXING MISSING COURSEASSIGNMENT_STUDENTS TABLE")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        from django.conf import settings
        from django.db import connection
        
        # Get database path
        db_path = settings.DATABASES['default']['NAME']
        print(f"Database path: {db_path}")
        
        # Connect to SQLite database directly
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='feedback_courseassignment_students';")
        table_exists = cursor.fetchone()
        
        if table_exists:
            print("✅ Table feedback_courseassignment_students already exists")
        else:
            print("❌ Table feedback_courseassignment_students missing - creating it...")
            
            # Create the missing intermediate table
            create_table_sql = """
            CREATE TABLE "feedback_courseassignment_students" (
                "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
                "courseassignment_id" bigint NOT NULL REFERENCES "feedback_courseassignment" ("id") DEFERRABLE INITIALLY DEFERRED,
                "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED
            );
            """
            
            cursor.execute(create_table_sql)
            
            # Create indexes
            cursor.execute("""
            CREATE INDEX "feedback_courseassignment_students_courseassignment_id_idx" 
            ON "feedback_courseassignment_students" ("courseassignment_id");
            """)
            
            cursor.execute("""
            CREATE INDEX "feedback_courseassignment_students_user_id_idx" 
            ON "feedback_courseassignment_students" ("user_id");
            """)
            
            # Create unique constraint
            cursor.execute("""
            CREATE UNIQUE INDEX "feedback_courseassignment_students_courseassignment_id_user_id_uniq" 
            ON "feedback_courseassignment_students" ("courseassignment_id", "user_id");
            """)
            
            conn.commit()
            print("✅ Table feedback_courseassignment_students created successfully")
        
        # Verify table structure
        cursor.execute("PRAGMA table_info(feedback_courseassignment_students);")
        columns = cursor.fetchall()
        
        print(f"\n📋 TABLE STRUCTURE:")
        print("-" * 40)
        for col in columns:
            print(f"  {col[1]} ({col[2]}) - {'NOT NULL' if col[3] else 'NULL'}")
        
        conn.close()
        
        # Test Django ORM access
        print(f"\n🧪 TESTING DJANGO ORM ACCESS:")
        print("-" * 40)
        
        from feedback.models import CourseAssignment
        from django.contrib.auth.models import User
        
        # Try to access the ManyToManyField
        try:
            # Get a CourseAssignment instance (or create one for testing)
            course_assignments = CourseAssignment.objects.all()
            print(f"✅ CourseAssignment.objects.all() works - {course_assignments.count()} assignments")
            
            # Test ManyToManyField access
            if course_assignments.exists():
                assignment = course_assignments.first()
                students = assignment.students.all()
                print(f"✅ assignment.students.all() works - {students.count()} students")
            else:
                print("ℹ️  No CourseAssignment instances to test ManyToManyField")
            
        except Exception as e:
            print(f"❌ Django ORM test failed: {e}")
        
        print(f"\n✅ DATABASE SCHEMA FIX COMPLETED!")
        print(f"The missing table has been created and should resolve the delete user error.")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
