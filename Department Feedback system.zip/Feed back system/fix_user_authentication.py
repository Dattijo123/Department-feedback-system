#!/usr/bin/env python
"""
Fix user authentication and department assignment issues
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("FIXING USER AUTHENTICATION & DEPARTMENT ISSUES")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        from feedback.models import UserProfile, Department
        from django.db import connection
        
        print("Step 1: Creating missing auth tables...")
        
        # Create missing auth tables manually
        with connection.cursor() as cursor:
            try:
                # Create auth_user_groups table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS auth_user_groups (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL REFERENCES auth_user(id),
                        group_id INTEGER NOT NULL REFERENCES auth_group(id),
                        UNIQUE(user_id, group_id)
                    );
                ''')
                
                # Create auth_user_user_permissions table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS auth_user_user_permissions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL REFERENCES auth_user(id),
                        permission_id INTEGER NOT NULL REFERENCES auth_permission(id),
                        UNIQUE(user_id, permission_id)
                    );
                ''')
                
                # Create auth_group table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS auth_group (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name VARCHAR(150) NOT NULL UNIQUE
                    );
                ''')
                
                # Create auth_group_permissions table
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS auth_group_permissions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        group_id INTEGER NOT NULL REFERENCES auth_group(id),
                        permission_id INTEGER NOT NULL REFERENCES auth_permission(id),
                        UNIQUE(group_id, permission_id)
                    );
                ''')
                
                print("✅ Auth tables created successfully")
                
            except Exception as e:
                print(f"⚠️  Auth tables might already exist: {e}")
        
        print("\nStep 2: Assigning departments to existing students...")
        
        # Get departments
        cs_dept = Department.objects.filter(code='CS').first()
        it_dept = Department.objects.filter(code='IT').first()
        se_dept = Department.objects.filter(code='SE').first()
        
        if not cs_dept:
            print("❌ CS department not found. Please run update_departments.py first.")
            return
        
        # Assign departments to students
        student_assignments = [
            ('student1', cs_dept),
            ('student2', it_dept if it_dept else cs_dept),
            ('student3', se_dept if se_dept else cs_dept),
        ]
        
        for username, department in student_assignments:
            try:
                user = User.objects.get(username=username)
                profile = UserProfile.objects.get(user=user)
                profile.department = department
                profile.save()
                print(f"✅ Assigned {username} to {department.code}")
            except (User.DoesNotExist, UserProfile.DoesNotExist):
                print(f"❌ User {username} or profile not found")
        
        print("\nStep 3: Verifying user authentication...")
        
        # Test authentication for all students
        from django.contrib.auth import authenticate
        
        test_students = ['student1', 'student2', 'student3', 'test_student']
        working_students = []
        
        for username in test_students:
            user = authenticate(username=username, password='student123')
            if user:
                try:
                    profile = UserProfile.objects.get(user=user)
                    dept_name = profile.department.code if profile.department else 'No Dept'
                    print(f"✅ {username} | Auth: SUCCESS | Dept: {dept_name}")
                    working_students.append((username, dept_name))
                except UserProfile.DoesNotExist:
                    print(f"⚠️  {username} | Auth: SUCCESS | Profile: MISSING")
            else:
                print(f"❌ {username} | Auth: FAILED")
        
        print("\nStep 4: Testing Add User functionality...")
        
        # Test the add user process
        test_username = 'new_test_student'
        
        # Remove if exists
        if User.objects.filter(username=test_username).exists():
            User.objects.filter(username=test_username).delete()
            print(f"🗑️  Removed existing {test_username}")
        
        # Create user using the same process as the add_user view
        try:
            new_user = User.objects.create_user(
                username=test_username,
                email='newtest@university.edu',
                password='newtest123',
                first_name='New',
                last_name='Student',
                is_staff=False
            )
            
            # Create profile
            UserProfile.objects.create(
                user=new_user,
                user_type='student',
                department=cs_dept,
                student_id=f"STU_{new_user.id:04d}"
            )
            
            print(f"✅ Created new user: {test_username}")
            
            # Test authentication
            auth_user = authenticate(username=test_username, password='newtest123')
            if auth_user:
                print(f"✅ New user authentication: SUCCESS")
                working_students.append((test_username, 'CS'))
            else:
                print(f"❌ New user authentication: FAILED")
                
        except Exception as e:
            print(f"❌ User creation failed: {e}")
        
        print("\n" + "=" * 60)
        print("🎯 STUDENT DASHBOARD ACCESS GUIDE")
        print("=" * 60)
        print("WORKING STUDENT ACCOUNTS:")
        for username, dept in working_students:
            print(f"   Username: {username}")
            print(f"   Password: student123" if username != 'new_test_student' else "   Password: newtest123")
            print(f"   Department: {dept}")
            print()
        
        print("STEP-BY-STEP LOGIN PROCESS:")
        print("1. Open browser and go to: http://localhost:8000/")
        print("2. Click 'Login' button or go to: http://localhost:8000/login/")
        print("3. Enter credentials (e.g., test_student / student123)")
        print("4. After successful login, you should be redirected to:")
        print("   http://localhost:8000/student-dashboard/")
        print("5. From dashboard, click 'View All Surveys' to see available surveys")
        
        print("\nDIRECT URLS FOR TESTING:")
        print("- Home: http://localhost:8000/")
        print("- Login: http://localhost:8000/login/")
        print("- Student Dashboard: http://localhost:8000/student-dashboard/")
        print("- Student Surveys: http://localhost:8000/student-surveys/")
        print("- Admin Dashboard: http://localhost:8000/admin-dashboard/")
        
        print("\nTROUBLESHOoting TIPS:")
        print("✅ If login fails, try 'test_student' / 'student123'")
        print("✅ If no surveys appear, check that surveys exist for the student's department")
        print("✅ If redirected to wrong dashboard, check user type in admin panel")
        print("✅ Use admin account (admin/admin123) to create more users if needed")
        
        print("\n🔧 ADD USER FUNCTIONALITY:")
        print("The Add User functionality should now work correctly.")
        print("- Go to: http://localhost:8000/admin-dashboard/")
        print("- Click 'Add User'")
        print("- Fill in the form and select a department")
        print("- New users should appear in 'Manage Users'")
        print("- New users can login immediately after creation")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
