#!/bin/bash

echo "========================================"
echo "Department Feedback System Setup"
echo "========================================"
echo

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3 from your package manager or https://www.python.org/"
    exit 1
fi

echo "Python found! Version:"
python3 --version
echo

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv venv
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to create virtual environment"
    exit 1
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "Upgrading pip..."
python -m pip install --upgrade pip

# Install requirements
echo "Installing Django and dependencies..."
pip install "Django>=4.2.0,<5.0.0"
pip install "Pillow>=10.0.0"

# Run migrations
echo "Running database migrations..."
python manage.py makemigrations
python manage.py migrate

echo
echo "========================================"
echo "Setup Complete!"
echo "========================================"
echo
echo "To activate the virtual environment:"
echo "source venv/bin/activate"
echo
echo "To create an admin user:"
echo "python manage.py createsuperuser"
echo
echo "To start the development server:"
echo "python manage.py runserver"
echo
echo "The application will be available at:"
echo "http://localhost:8000"
echo
