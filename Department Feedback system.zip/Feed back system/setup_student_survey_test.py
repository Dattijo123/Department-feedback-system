#!/usr/bin/env python
"""
Set up a complete survey with questions for testing the student interface
"""

import os
import sys
import django
from datetime import datetime, timedelta

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("Setting Up Student Survey Interface Test")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        from feedback.models import Department, Survey, Question, QuestionChoice, UserProfile
        from django.utils import timezone
        
        # Get admin user
        admin_user = User.objects.filter(is_staff=True).first()
        if not admin_user:
            print("❌ No admin user found. Please create an admin user first.")
            return
        
        # Get CS department
        cs_department = Department.objects.filter(code='CS').first()
        if not cs_department:
            print("❌ CS department not found. Please run update_departments.py first.")
            return
        
        # Create an active survey for testing
        survey = Survey.objects.create(
            title="Course Feedback Survey - Cybersecurity Fundamentals",
            description="Please provide your feedback on the Cybersecurity Fundamentals course. Your responses help us improve the learning experience for future students.",
            survey_type="course_evaluation",
            department=cs_department,
            created_by=admin_user,
            start_date=timezone.now() - timedelta(days=1),  # Started yesterday
            end_date=timezone.now() + timedelta(days=14),   # Ends in 2 weeks
            is_active=True  # Make it active for students
        )
        
        print(f"✅ Active survey created: {survey.title}")
        
        # Add different types of questions
        questions_data = [
            {
                'text': 'How would you rate the overall quality of this course?',
                'question_type': 'rating',
                'is_required': True,
                'order': 1
            },
            {
                'text': 'Which teaching method was most effective for your learning?',
                'question_type': 'multiple_choice',
                'is_required': True,
                'order': 2,
                'choices': [
                    'Interactive lectures',
                    'Hands-on lab exercises',
                    'Group discussions',
                    'Case study analysis',
                    'Online resources'
                ]
            },
            {
                'text': 'Would you recommend this course to other students?',
                'question_type': 'yes_no',
                'is_required': True,
                'order': 3
            },
            {
                'text': 'How would you rate the course materials and resources?',
                'question_type': 'rating',
                'is_required': True,
                'order': 4
            },
            {
                'text': 'What improvements would you suggest for this course?',
                'question_type': 'text',
                'is_required': False,
                'order': 5
            },
            {
                'text': 'How would you rate the instructor\'s teaching effectiveness?',
                'question_type': 'rating',
                'is_required': True,
                'order': 6
            },
            {
                'text': 'Did the course meet your learning expectations?',
                'question_type': 'yes_no',
                'is_required': True,
                'order': 7
            },
            {
                'text': 'Any additional comments or feedback?',
                'question_type': 'text',
                'is_required': False,
                'order': 8
            }
        ]
        
        for q_data in questions_data:
            question = Question.objects.create(
                survey=survey,
                text=q_data['text'],
                question_type=q_data['question_type'],
                is_required=q_data['is_required'],
                order=q_data['order']
            )
            
            # Add choices for multiple choice questions
            if q_data['question_type'] == 'multiple_choice' and 'choices' in q_data:
                for i, choice_text in enumerate(q_data['choices']):
                    QuestionChoice.objects.create(
                        question=question,
                        text=choice_text,
                        value=choice_text.lower().replace(' ', '_'),
                        order=i + 1
                    )
            
            print(f"✅ Added question {q_data['order']}: {q_data['question_type']}")
        
        # Ensure we have student users in CS department
        cs_students = UserProfile.objects.filter(
            user_type='student',
            department=cs_department
        )
        
        if not cs_students.exists():
            print("\n⚠️  No students found in CS department. Creating test student...")
            
            # Create a test student
            test_student = User.objects.create_user(
                username='test_student',
                email='student@test.edu',
                password='student123',
                first_name='Test',
                last_name='Student'
            )
            
            UserProfile.objects.create(
                user=test_student,
                user_type='student',
                department=cs_department,
                student_id=f"STU_{test_student.id:04d}"
            )
            
            print(f"✅ Created test student: test_student / student123")
        
        print("\n" + "=" * 60)
        print("🧪 STUDENT SURVEY INTERFACE TESTING:")
        print("=" * 60)
        print("1. Login as a student:")
        print("   - Username: student1 / Password: student123")
        print("   - OR Username: test_student / Password: student123")
        print()
        print("2. Test URLs:")
        print("   - Student Dashboard: http://localhost:8000/student-dashboard/")
        print("   - Student Surveys: http://localhost:8000/student-surveys/")
        print(f"   - Take Survey: http://localhost:8000/survey/{survey.id}/take/")
        print()
        print("3. Test Features:")
        print("   ✅ Survey access control (students only)")
        print("   ✅ Department-based survey filtering")
        print("   ✅ All 4 question types rendering")
        print("   ✅ Form validation and progress tracking")
        print("   ✅ Anonymous submission system")
        print("   ✅ Duplicate submission prevention")
        print()
        print("4. Survey Details:")
        print(f"   - Survey ID: {survey.id}")
        print(f"   - Questions: {Question.objects.filter(survey=survey).count()}")
        print(f"   - Required: {Question.objects.filter(survey=survey, is_required=True).count()}")
        print(f"   - Optional: {Question.objects.filter(survey=survey, is_required=False).count()}")
        print(f"   - Active until: {survey.end_date.strftime('%Y-%m-%d %H:%M')}")
        
        print("\n🎯 TESTING CHECKLIST:")
        print("   □ Login as student")
        print("   □ View student dashboard")
        print("   □ Navigate to surveys list")
        print("   □ Take the survey")
        print("   □ Test all question types")
        print("   □ Submit feedback")
        print("   □ Verify completion status")
        print("   □ Try to take survey again (should be blocked)")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
