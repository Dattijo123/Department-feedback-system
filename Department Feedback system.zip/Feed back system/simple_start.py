#!/usr/bin/env python
"""
Simple startup script to get the feedback system running
This creates a basic working version first
"""

import os
import sys
import django
from django.core.management import execute_from_command_line

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 50)
    print("Department Feedback System - Simple Start")
    print("=" * 50)
    print()
    
    try:
        # Test Django setup
        django.setup()
        print("✓ Django setup successful")
        
        # Run migrations
        print("Running migrations...")
        execute_from_command_line(['manage.py', 'migrate', '--run-syncdb'])
        print("✓ Migrations completed")
        
        # Create superuser
        print("\nCreating admin user...")
        from django.contrib.auth.models import User
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser('admin', 'admin@example.com', 'admin123')
            print("✓ Admin user created: username='admin', password='admin123'")
        else:
            print("✓ Admin user already exists")
        
        print("\n" + "=" * 50)
        print("Setup Complete!")
        print("=" * 50)
        print("You can now run: venv\\Scripts\\python.exe manage.py runserver")
        print("Then visit: http://localhost:8000")
        print("Admin login: admin / admin123")
        
    except Exception as e:
        print(f"Error: {e}")
        print("Please check your Django installation and try again.")

if __name__ == "__main__":
    main()
