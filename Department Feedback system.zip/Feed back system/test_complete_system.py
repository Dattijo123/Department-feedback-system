#!/usr/bin/env python
"""
Test the complete student survey system
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("TESTING COMPLETE STUDENT SURVEY SYSTEM")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        from feedback.models import Survey, Question, QuestionChoice, UserProfile, Department
        
        print("1. VERIFYING SYSTEM COMPONENTS:")
        print("-" * 40)
        
        # Check users
        students = UserProfile.objects.filter(user_type='student')
        print(f"✅ Students: {students.count()}")
        for student in students:
            dept = student.department.code if student.department else 'No Dept'
            print(f"   - {student.user.username} ({dept})")
        
        # Check departments
        departments = Department.objects.all()
        print(f"✅ Departments: {departments.count()}")
        
        # Check surveys
        active_surveys = Survey.objects.filter(is_active=True)
        print(f"✅ Active Surveys: {active_surveys.count()}")
        
        for survey in active_surveys:
            questions = Question.objects.filter(survey=survey)
            print(f"   - {survey.title} ({questions.count()} questions)")
        
        print("\n2. TESTING STUDENT DASHBOARD ACCESS:")
        print("-" * 40)
        
        # Test student authentication
        test_student = User.objects.filter(username='test_student').first()
        if test_student:
            from django.contrib.auth import authenticate
            auth_result = authenticate(username='test_student', password='student123')
            if auth_result:
                print("✅ Student authentication: SUCCESS")
                
                # Check student profile
                try:
                    profile = UserProfile.objects.get(user=test_student)
                    print(f"✅ Student profile: {profile.user_type} in {profile.department.code}")
                except UserProfile.DoesNotExist:
                    print("❌ Student profile: NOT FOUND")
            else:
                print("❌ Student authentication: FAILED")
        else:
            print("❌ Test student not found")
        
        print("\n3. TESTING SURVEY QUESTIONS:")
        print("-" * 40)
        
        if active_surveys.exists():
            test_survey = active_surveys.first()
            questions = Question.objects.filter(survey=test_survey).order_by('order')
            
            print(f"Survey: {test_survey.title}")
            print(f"Questions: {questions.count()}")
            
            for question in questions:
                print(f"\nQ{question.order}: {question.question_type}")
                print(f"  Text: {question.text[:50]}...")
                print(f"  Required: {question.is_required}")
                
                if question.question_type == 'multiple_choice':
                    choices = QuestionChoice.objects.filter(question=question)
                    print(f"  Choices: {choices.count()}")
                    for choice in choices:
                        print(f"    - '{choice.text}' (value: '{choice.value}')")
        
        print("\n4. CREATING FRESH TEST DATA:")
        print("-" * 40)
        
        # Ensure we have a clean test survey
        Survey.objects.filter(title__contains='Test Survey for Debugging').delete()
        
        cs_dept = Department.objects.filter(code='CS').first()
        admin_user = User.objects.filter(is_staff=True).first()
        
        if cs_dept and admin_user:
            from django.utils import timezone
            from datetime import timedelta
            
            # Create a simple test survey
            test_survey = Survey.objects.create(
                title='Test Survey for Debugging',
                description='Simple survey to test submission functionality',
                survey_type='course_evaluation',
                department=cs_dept,
                created_by=admin_user,
                start_date=timezone.now(),
                end_date=timezone.now() + timedelta(days=7),
                is_active=True
            )
            
            # Add simple questions
            q1 = Question.objects.create(
                survey=test_survey,
                text='How would you rate this test?',
                question_type='rating',
                is_required=True,
                order=1
            )
            
            q2 = Question.objects.create(
                survey=test_survey,
                text='Would you recommend this system?',
                question_type='yes_no',
                is_required=True,
                order=2
            )
            
            q3 = Question.objects.create(
                survey=test_survey,
                text='Which feature do you like most?',
                question_type='multiple_choice',
                is_required=True,
                order=3
            )
            
            # Add choices for multiple choice
            QuestionChoice.objects.create(
                question=q3,
                text='User Interface',
                value='ui',
                order=1
            )
            
            QuestionChoice.objects.create(
                question=q3,
                text='Functionality',
                value='functionality',
                order=2
            )
            
            QuestionChoice.objects.create(
                question=q3,
                text='Performance',
                value='performance',
                order=3
            )
            
            q4 = Question.objects.create(
                survey=test_survey,
                text='Any additional comments?',
                question_type='text',
                is_required=False,
                order=4
            )
            
            print(f"✅ Created test survey: ID {test_survey.id}")
            print(f"✅ Added 4 questions with proper choices")
            
            print("\n" + "=" * 60)
            print("🎯 TESTING INSTRUCTIONS:")
            print("=" * 60)
            print("1. FIXED ISSUES:")
            print("   ✅ Student dashboard QuerySet display fixed")
            print("   ✅ Survey submission error handling improved")
            print("   ✅ Multiple choice validation enhanced")
            print("   ✅ JavaScript button state logic fixed")
            
            print("\n2. TEST THE FIXES:")
            print("   Step 1: Login as student")
            print("     URL: http://localhost:8000/login/")
            print("     Credentials: test_student / student123")
            
            print("\n   Step 2: Check student dashboard")
            print("     URL: http://localhost:8000/student-dashboard/")
            print("     Expected: Should show numbers, not QuerySet text")
            
            print("\n   Step 3: Take the test survey")
            print(f"     URL: http://localhost:8000/survey/{test_survey.id}/take/")
            print("     Expected: All question types should work")
            
            print("\n   Step 4: Submit survey")
            print("     Fill all required fields and submit")
            print("     Expected: Success message and redirect")
            
            print("\n3. DEBUGGING TIPS:")
            print("   - Check browser console for JavaScript errors")
            print("   - Look for Django error messages on the page")
            print("   - Verify all required fields are filled")
            print("   - Check that submit button is enabled")
            
            print("\n4. COMMON ISSUES FIXED:")
            print("   ✅ QuerySet display → Now shows counts")
            print("   ✅ Multiple choice validation → Better error messages")
            print("   ✅ Submit button state → Fixed CSS class logic")
            print("   ✅ Error handling → More detailed messages")
            
        else:
            print("❌ Missing CS department or admin user")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
