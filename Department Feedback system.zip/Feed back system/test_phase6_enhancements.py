#!/usr/bin/env python
"""
Test Phase 6 Enhanced Analytics functionality
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("TESTING PHASE 6: ENHANCED ANALYTICS & RESULTS")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        from django.contrib.auth.models import User
        from feedback.models import Survey, FeedbackSubmission, UserProfile, Department
        
        print("1. VERIFYING ENHANCED ADMIN DASHBOARD:")
        print("-" * 40)
        
        # Check data for enhanced dashboard
        total_surveys = Survey.objects.count()
        total_submissions = FeedbackSubmission.objects.count()
        departments = Department.objects.count()
        
        print(f"✅ Total Surveys: {total_surveys}")
        print(f"✅ Total Submissions: {total_submissions}")
        print(f"✅ Departments: {departments}")
        
        # Check surveys with feedback for quick access
        surveys_with_feedback = []
        for survey in Survey.objects.all():
            feedback_count = FeedbackSubmission.objects.filter(survey=survey).count()
            if feedback_count > 0:
                surveys_with_feedback.append((survey.id, survey.title, feedback_count))
        
        print(f"✅ Surveys with feedback: {len(surveys_with_feedback)}")
        for survey_id, title, count in surveys_with_feedback:
            print(f"   Survey {survey_id}: {title} ({count} responses)")
        
        print("\n2. TESTING EXPORT FUNCTIONALITY:")
        print("-" * 40)
        
        if surveys_with_feedback:
            test_survey_id = surveys_with_feedback[0][0]
            print(f"✅ Test survey for export: ID {test_survey_id}")
            print(f"   CSV Export URL: http://localhost:8000/export/survey/{test_survey_id}/csv/")
            print(f"   PDF Export URL: http://localhost:8000/export/survey/{test_survey_id}/pdf/")
        else:
            print("❌ No surveys with feedback available for export testing")
        
        print("\n3. TESTING DEPARTMENT ANALYTICS:")
        print("-" * 40)
        
        # Check department analytics data
        for dept in Department.objects.all():
            dept_surveys = Survey.objects.filter(department=dept).count()
            dept_students = UserProfile.objects.filter(user_type='student', department=dept).count()
            dept_lecturers = UserProfile.objects.filter(user_type='lecturer', department=dept).count()
            dept_submissions = FeedbackSubmission.objects.filter(survey__department=dept).count()
            
            print(f"✅ {dept.code} - {dept.name}:")
            print(f"   Surveys: {dept_surveys}, Students: {dept_students}, Lecturers: {dept_lecturers}")
            print(f"   Submissions: {dept_submissions}")
            
            # Calculate response rate
            if dept_students > 0 and dept_surveys > 0:
                expected = dept_students * dept_surveys
                response_rate = (dept_submissions / expected * 100) if expected > 0 else 0
                print(f"   Response Rate: {response_rate:.1f}%")
        
        print("\n4. TESTING TREND ANALYSIS:")
        print("-" * 40)
        
        from django.utils import timezone
        from datetime import timedelta
        
        # Check recent submissions for trend analysis
        recent_submissions = FeedbackSubmission.objects.filter(
            submitted_at__gte=timezone.now() - timedelta(days=30)
        ).count()
        
        previous_submissions = FeedbackSubmission.objects.filter(
            submitted_at__gte=timezone.now() - timedelta(days=60),
            submitted_at__lt=timezone.now() - timedelta(days=30)
        ).count()
        
        print(f"✅ Recent submissions (30 days): {recent_submissions}")
        print(f"✅ Previous submissions (30 days): {previous_submissions}")
        
        if recent_submissions > previous_submissions:
            trend = "Increasing"
        elif recent_submissions < previous_submissions:
            trend = "Decreasing"
        else:
            trend = "Stable"
        
        print(f"✅ Overall trend: {trend}")
        
        print("\n" + "=" * 60)
        print("🧪 PHASE 6 TESTING INSTRUCTIONS:")
        print("=" * 60)
        
        print("\n1. **Test Enhanced Admin Dashboard:**")
        print("   • Login as admin: admin / admin123")
        print("   • Go to: http://localhost:8000/admin-dashboard/")
        print("   • Expected: Enhanced statistics cards with 6 metrics")
        print("   • Expected: Department analytics table")
        print("   • Expected: Surveys with feedback - quick access section")
        print("   • Expected: Export buttons (CSV/Report) on survey cards")
        
        print("\n2. **Test Export Functionality:**")
        if surveys_with_feedback:
            test_id = surveys_with_feedback[0][0]
            print(f"   • Go to survey results: http://localhost:8000/admin-survey/{test_id}/results/")
            print("   • Click 'Export CSV' button")
            print("   • Expected: CSV file download with survey data")
            print("   • Click 'Export Report' button")
            print("   • Expected: Text report file download")
            print("   • Test from dashboard quick access cards")
        
        print("\n3. **Test Department Analytics:**")
        print("   • From admin dashboard, click 'Detailed Analytics' button")
        print("   • URL: http://localhost:8000/department-analytics/")
        print("   • Expected: Comprehensive department comparison")
        print("   • Expected: Trend analysis with arrows")
        print("   • Expected: Response rate progress bars")
        print("   • Expected: Top performing surveys per department")
        
        print("\n4. **Test Enhanced Survey Results:**")
        if surveys_with_feedback:
            test_id = surveys_with_feedback[0][0]
            print(f"   • Go to: http://localhost:8000/admin-survey/{test_id}/results/")
            print("   • Expected: Export buttons in header")
            print("   • Expected: Enhanced statistics display")
            print("   • Test both CSV and Report export")
        
        print("\n🎯 PHASE 6 FEATURES VERIFICATION:")
        print("-" * 40)
        print("✅ Enhanced Admin Dashboard:")
        print("   • System-wide overview with 6 key metrics")
        print("   • Department comparison table")
        print("   • Quick access to surveys with feedback")
        print("   • Export buttons on survey cards")
        
        print("\n✅ Export Functionality:")
        print("   • CSV export with detailed survey data")
        print("   • Text-based report export")
        print("   • Export buttons in survey results pages")
        print("   • Export buttons in dashboard quick access")
        
        print("\n✅ Department Analytics:")
        print("   • Comprehensive department comparison")
        print("   • 30-day trend analysis")
        print("   • Response rate visualization")
        print("   • Top performing surveys identification")
        
        print("\n✅ Enhanced Visualizations:")
        print("   • Progress bars for response rates")
        print("   • Trend indicators (arrows)")
        print("   • Color-coded statistics")
        print("   • Department performance comparison")
        
        print("\n🔧 URLS FOR TESTING:")
        print("-" * 40)
        print("✅ Enhanced Admin Dashboard: http://localhost:8000/admin-dashboard/")
        print("✅ Department Analytics: http://localhost:8000/department-analytics/")
        if surveys_with_feedback:
            test_id = surveys_with_feedback[0][0]
            print(f"✅ Survey Results: http://localhost:8000/admin-survey/{test_id}/results/")
            print(f"✅ CSV Export: http://localhost:8000/export/survey/{test_id}/csv/")
            print(f"✅ Report Export: http://localhost:8000/export/survey/{test_id}/pdf/")
        
        print("\n📊 PHASE 6 ENHANCEMENT SUMMARY:")
        print("-" * 40)
        print("✅ Built upon Phase 5 foundation without duplication")
        print("✅ Enhanced admin dashboard with system-wide analytics")
        print("✅ Added practical export functionality (CSV/Report)")
        print("✅ Implemented simple trend analysis")
        print("✅ Created department comparison tools")
        print("✅ Maintained simplicity and user-friendliness")
        print("✅ Preserved access control and security")
        
        print("\n🎉 PHASE 6: ENHANCED ANALYTICS READY FOR TESTING!")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
