#!/usr/bin/env python
"""
Update departments - Remove Computer Science and update technology departments
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 60)
    print("Updating University Departments")
    print("=" * 60)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from feedback.models import Department
        
        print("Step 1: Removing old Computer Science department...")
        
        # Remove old Computer Science department if it exists
        old_cs_dept = Department.objects.filter(name__icontains='Computer Science').first()
        if old_cs_dept:
            print(f"✓ Removed: {old_cs_dept.code} - {old_cs_dept.name}")
            old_cs_dept.delete()
        else:
            print("- No old Computer Science department found")
        
        print("\nStep 2: Updating technology departments...")
        
        # Updated department data with correct technology departments
        departments = [
            ('LAW', 'Department of Law'),
            ('MHS', 'Department of Medical and Health Sciences'),
            ('NUR', 'Department of Nursing'),
            ('PH', 'Department of Public Health'),
            ('IT', 'Department of Information Technology'),  # Updated
            ('SE', 'Department of Software Engineering'),     # Updated
            ('CS', 'Department of Cyber Security'),          # Updated
            ('IR', 'Department of International Relations'),
            ('BA', 'Department of Business Administration'),
            ('MC', 'Department of Mass Communication'),
        ]
        
        created_count = 0
        updated_count = 0
        
        for code, name in departments:
            department, created = Department.objects.update_or_create(
                code=code,
                defaults={
                    'name': name,
                    'description': f'{name} - Academic department offering specialized programs and courses.'
                }
            )
            
            if created:
                print(f"✓ Created: {code} - {name}")
                created_count += 1
            else:
                print(f"✓ Updated: {code} - {name}")
                updated_count += 1
        
        print(f"\n✓ Created {created_count} new departments")
        print(f"✓ Updated {updated_count} existing departments")
        print(f"✓ Total departments: {Department.objects.count()}")
        
        print("\n" + "=" * 60)
        print("UPDATED DEPARTMENT LIST:")
        print("=" * 60)
        for dept in Department.objects.all().order_by('code'):
            print(f"  {dept.code} - {dept.name}")
        
        print("\n" + "=" * 60)
        print("Departments Updated Successfully!")
        print("=" * 60)
        print("✓ Technology departments properly configured")
        print("✓ All departments available for survey creation")
        print("✓ User assignment departments updated")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
