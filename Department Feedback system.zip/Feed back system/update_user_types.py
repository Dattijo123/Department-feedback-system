#!/usr/bin/env python
"""
Update user types in UserProfile for proper categorization
"""

import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'feedback_system.settings')

def main():
    print("=" * 50)
    print("Updating User Types")
    print("=" * 50)
    print()
    
    try:
        # Setup Django
        django.setup()
        
        # Import after Django setup
        from django.contrib.auth.models import User
        from feedback.models import UserProfile
        
        # Update user types based on usernames
        user_type_mapping = {
            'admin': 'admin',
            'dept_admin': 'admin',
            'prof_smith': 'lecturer',
            'prof_johnson': 'lecturer',
            'dr_brown': 'lecturer',
            'student1': 'student',
            'student2': 'student',
            'student3': 'student',
        }
        
        for username, user_type in user_type_mapping.items():
            try:
                user = User.objects.get(username=username)
                profile = UserProfile.objects.get(user=user)
                profile.user_type = user_type
                
                # Set appropriate IDs
                if user_type == 'lecturer':
                    profile.employee_id = f"EMP_{user.id:04d}"
                elif user_type == 'student':
                    profile.student_id = f"STU_{user.id:04d}"
                
                profile.save()
                print(f"✓ Updated {username} -> {user_type}")
                
            except User.DoesNotExist:
                print(f"- User {username} not found")
            except UserProfile.DoesNotExist:
                print(f"- Profile for {username} not found")
        
        print("\n" + "=" * 50)
        print("User Types Updated Successfully!")
        print("=" * 50)
        
        # Show current counts
        students = UserProfile.objects.filter(user_type='student').count()
        lecturers = UserProfile.objects.filter(user_type='lecturer').count()
        admins = UserProfile.objects.filter(user_type='admin').count()
        
        print(f"📊 Current User Counts:")
        print(f"   Students: {students}")
        print(f"   Lecturers: {lecturers}")
        print(f"   Admins: {admins}")
        
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
